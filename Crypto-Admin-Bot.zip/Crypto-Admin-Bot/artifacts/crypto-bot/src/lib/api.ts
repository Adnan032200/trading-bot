import { setAuthTokenGetter } from "@workspace/api-client-react";

// In-memory token storage (also saved to localStorage in AuthContext)
let currentToken: string | null = null;

export const setAuthToken = (token: string | null) => {
  currentToken = token;
};

// This tells the custom-fetch to always use the current token
setAuthTokenGetter(() => currentToken);
