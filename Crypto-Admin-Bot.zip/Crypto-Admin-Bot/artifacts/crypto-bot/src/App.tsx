import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/protected-route";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";
import DashboardPage from "@/pages/dashboard";
import MarketPage from "@/pages/market";
import TradingPage from "@/pages/trading";
import HistoryPage from "@/pages/history";
import SettingsPage from "@/pages/settings";
import SubscribePage from "@/pages/subscribe";
import AdminPage from "@/pages/admin/index";
import AdminUsersPage from "@/pages/admin/users";
import AdminIpsPage from "@/pages/admin/ips";
import AdminPlansPage from "@/pages/admin/plans";
import AdminTradesPage from "@/pages/admin/trades";
import AdminSettingsPage from "@/pages/admin/settings";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30000 } },
});

function AppRoutes() {
  return (
    <Switch>
      <Route path="/" component={() => <Redirect to="/dashboard" />} />
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      <Route path="/dashboard" component={() => (
        <ProtectedRoute><Layout><DashboardPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/market" component={() => (
        <ProtectedRoute><Layout><MarketPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/trading" component={() => (
        <ProtectedRoute><Layout><TradingPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/history" component={() => (
        <ProtectedRoute><Layout><HistoryPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/settings" component={() => (
        <ProtectedRoute><Layout><SettingsPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/subscribe" component={() => (
        <ProtectedRoute><Layout><SubscribePage /></Layout></ProtectedRoute>
      )} />
      <Route path="/admin" component={() => (
        <ProtectedRoute requireAdmin><Layout><AdminPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/admin/users" component={() => (
        <ProtectedRoute requireAdmin><Layout><AdminUsersPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/admin/ips" component={() => (
        <ProtectedRoute requireAdmin><Layout><AdminIpsPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/admin/plans" component={() => (
        <ProtectedRoute requireAdmin><Layout><AdminPlansPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/admin/trades" component={() => (
        <ProtectedRoute requireAdmin><Layout><AdminTradesPage /></Layout></ProtectedRoute>
      )} />
      <Route path="/admin/settings" component={() => (
        <ProtectedRoute requireAdmin><Layout><AdminSettingsPage /></Layout></ProtectedRoute>
      )} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <AppRoutes />
          </WouterRouter>
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
