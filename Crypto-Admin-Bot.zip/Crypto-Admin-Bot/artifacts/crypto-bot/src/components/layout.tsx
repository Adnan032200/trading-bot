import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { 
  Activity, 
  BarChart2, 
  Settings, 
  History, 
  LogOut, 
  CreditCard,
  ShieldAlert,
  Users,
  Ban,
  ListPlus,
  Server
} from "lucide-react";
import { useLogout } from "@workspace/api-client-react";

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout, isAdmin } = useAuth();
  const [location] = useLocation();
  const logoutMutation = useLogout();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSettled: () => {
        logout();
      }
    });
  };

  const NavItem = ({ href, icon: Icon, label }: { href: string, icon: any, label: string }) => {
    const isActive = location === href || location.startsWith(`${href}/`);
    return (
      <Link href={href} className={`flex items-center gap-3 px-4 py-3 rounded-md transition-colors ${isActive ? 'bg-primary/10 text-primary border border-primary/20' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>
        <Icon className="w-5 h-5" />
        <span className="font-mono text-sm font-medium tracking-wide">{label}</span>
      </Link>
    );
  };

  return (
    <div className="min-h-screen flex bg-background text-foreground selection:bg-primary/30">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-card flex flex-col h-screen sticky top-0">
        <div className="p-6 border-b border-border flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-background font-black text-xl shadow-[0_0_15px_rgba(0,255,136,0.5)]">
            X
          </div>
          <div>
            <h1 className="font-mono font-bold text-lg tracking-wider text-primary">NEXUS<span className="text-muted-foreground">_</span>BOT</h1>
            <div className="text-xs text-muted-foreground font-mono flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-primary shadow-[0_0_5px_rgba(0,255,136,0.8)] animate-pulse"></span>
              SYSTEM ONLINE
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          <div className="text-xs font-mono text-muted-foreground mb-4 mt-2 px-2 uppercase tracking-widest">Core</div>
          <NavItem href="/dashboard" icon={Activity} label="DASHBOARD" />
          <NavItem href="/market" icon={BarChart2} label="MARKET_SCAN" />
          <NavItem href="/trading" icon={Activity} label="AUTO_TRADE" />
          <NavItem href="/history" icon={History} label="HISTORY" />
          
          <div className="text-xs font-mono text-muted-foreground mb-4 mt-8 px-2 uppercase tracking-widest">Account</div>
          <NavItem href="/settings" icon={Settings} label="SETTINGS" />
          <NavItem href="/subscribe" icon={CreditCard} label="SUBSCRIPTION" />

          {isAdmin && (
            <>
              <div className="text-xs font-mono text-destructive mb-4 mt-8 px-2 uppercase tracking-widest flex items-center gap-2">
                <ShieldAlert className="w-3 h-3" />
                Admin_Override
              </div>
              <NavItem href="/admin" icon={Server} label="OVERVIEW" />
              <NavItem href="/admin/users" icon={Users} label="USERS" />
              <NavItem href="/admin/ips" icon={Ban} label="BLOCKED_IPS" />
              <NavItem href="/admin/plans" icon={ListPlus} label="PLANS" />
              <NavItem href="/admin/trades" icon={History} label="ALL_TRADES" />
              <NavItem href="/admin/settings" icon={Settings} label="SYS_CONFIG" />
            </>
          )}
        </nav>

        <div className="p-4 border-t border-border bg-muted/20">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded bg-muted flex items-center justify-center border border-border font-mono text-muted-foreground">
              {user?.username.charAt(0).toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <div className="text-sm font-mono truncate">{user?.username}</div>
              <div className="text-xs text-muted-foreground truncate">{user?.email}</div>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-destructive/10 text-destructive hover:bg-destructive/20 border border-destructive/20 rounded font-mono text-sm transition-colors"
          >
            <LogOut className="w-4 h-4" />
            DISCONNECT
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <header className="h-16 border-b border-border bg-background flex items-center px-6 sticky top-0 z-10">
          <div className="flex-1"></div>
          <div className="flex items-center gap-4">
             <div className="text-xs font-mono px-3 py-1 rounded bg-muted/50 border border-border flex items-center gap-2">
               <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
               {user?.role === 'admin' ? 'ADMIN_PRIVILEGES' : 'STANDARD_ACCESS'}
             </div>
          </div>
        </header>
        <div className="flex-1 overflow-y-auto p-6 lg:p-8 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-card/40 via-background to-background">
          {children}
        </div>
      </main>
    </div>
  );
}
