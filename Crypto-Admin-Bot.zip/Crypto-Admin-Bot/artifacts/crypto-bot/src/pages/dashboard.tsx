import { useGetTradingStatus, useGetPerformance, useGetBalance, useGetMarketSummary, useGetTopGainers, useGetTopLosers, useStartTrading, useStopTrading, getGetTradingStatusQueryKey, getGetPerformanceQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown, Activity, DollarSign, BarChart2, Zap, ZapOff } from "lucide-react";

function StatCard({ label, value, sub, accent = false }: { label: string; value: string; sub?: string; accent?: boolean }) {
  return (
    <div className="bg-card border border-border rounded-lg p-5 relative overflow-hidden">
      <div className={`absolute top-0 left-0 w-full h-px ${accent ? 'bg-primary' : 'bg-border'}`} />
      <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-1">{label}</p>
      <p className={`text-2xl font-mono font-bold ${accent ? 'text-primary' : 'text-foreground'}`}>{value}</p>
      {sub && <p className="text-xs font-mono text-muted-foreground mt-1">{sub}</p>}
    </div>
  );
}

export default function DashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: status, isLoading: statusLoading } = useGetTradingStatus();
  const { data: performance, isLoading: perfLoading } = useGetPerformance();
  const { data: balance } = useGetBalance();
  const { data: marketSummary } = useGetMarketSummary();
  const { data: gainers } = useGetTopGainers();
  const { data: losers } = useGetTopLosers();

  const startMutation = useStartTrading();
  const stopMutation = useStopTrading();

  const handleToggle = () => {
    if (status?.isRunning) {
      stopMutation.mutate(undefined, {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getGetTradingStatusQueryKey() });
          toast({ title: "Bot stopped", description: "Trading agent disconnected" });
        },
      });
    } else {
      startMutation.mutate(undefined, {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getGetTradingStatusQueryKey() });
          toast({ title: "Bot started", description: "Trading agent initialized" });
        },
      });
    }
  };

  const isToggling = startMutation.isPending || stopMutation.isPending;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-mono font-bold tracking-wide">MISSION_CONTROL</h1>
          <p className="text-sm font-mono text-muted-foreground mt-1">Welcome back, {user?.username}</p>
        </div>
        <button
          data-testid="button-toggle-bot"
          onClick={handleToggle}
          disabled={isToggling}
          className={`flex items-center gap-2 px-6 py-3 rounded font-mono text-sm font-bold tracking-widest transition-all ${
            status?.isRunning
              ? 'bg-destructive/10 text-destructive border border-destructive/30 hover:bg-destructive/20 shadow-[0_0_15px_rgba(255,51,102,0.2)]'
              : 'bg-primary/10 text-primary border border-primary/30 hover:bg-primary/20 shadow-[0_0_15px_rgba(0,255,136,0.2)]'
          }`}
        >
          {status?.isRunning ? <ZapOff className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
          {isToggling ? 'PROCESSING...' : status?.isRunning ? 'HALT_BOT' : 'LAUNCH_BOT'}
        </button>
      </div>

      {/* Bot Status */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className={`w-3 h-3 rounded-full ${status?.isRunning ? 'bg-primary shadow-[0_0_8px_rgba(0,255,136,0.8)] animate-pulse' : 'bg-muted-foreground'}`} />
          <span className="font-mono text-sm font-bold tracking-widest">{status?.isRunning ? 'BOT_ACTIVE' : 'BOT_OFFLINE'}</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 font-mono">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Current Symbol</p>
            <p className="text-lg font-bold text-primary">{status?.currentSymbol ?? '---'}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Position</p>
            <p className="text-lg font-bold">{status?.position ?? '---'}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Live PNL</p>
            <p className={`text-lg font-bold ${status?.pnl != null ? (status.pnl >= 0 ? 'text-primary' : 'text-destructive') : ''}`}>
              {status?.pnl != null ? `${status.pnl >= 0 ? '+' : ''}${status.pnl.toFixed(4)} USDT` : '---'}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">USDT Balance</p>
            <p className="text-lg font-bold text-secondary">{balance ? `${balance.usdtBalance.toFixed(2)} USDT` : '---'}</p>
          </div>
        </div>
      </div>

      {/* Performance Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {perfLoading ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-lg" />)
        ) : (
          <>
            <StatCard label="Total Trades" value={String(performance?.totalTrades ?? 0)} sub={`${performance?.openTrades ?? 0} open`} />
            <StatCard label="Win Rate" value={`${performance?.winRate ?? 0}%`} accent />
            <StatCard label="Net Profit" value={`${(performance?.netProfit ?? 0) >= 0 ? '+' : ''}${(performance?.netProfit ?? 0).toFixed(2)}`} sub="USDT" accent={(performance?.netProfit ?? 0) >= 0} />
            <StatCard label="Open Positions" value={String(performance?.openTrades ?? 0)} />
          </>
        )}
      </div>

      {/* Market Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">Market_Overview</h3>
          {marketSummary ? (
            <div className="space-y-3">
              <div className="flex justify-between font-mono text-sm">
                <span className="text-muted-foreground">Total Coins</span>
                <span className="font-bold">{marketSummary.totalCoins}</span>
              </div>
              <div className="flex justify-between font-mono text-sm">
                <span className="text-primary">Rising</span>
                <span className="text-primary font-bold">{marketSummary.upCount}</span>
              </div>
              <div className="flex justify-between font-mono text-sm">
                <span className="text-destructive">Falling</span>
                <span className="text-destructive font-bold">{marketSummary.downCount}</span>
              </div>
              <div className="flex justify-between font-mono text-sm">
                <span className="text-muted-foreground">Stable</span>
                <span className="font-bold">{marketSummary.stableCount}</span>
              </div>
            </div>
          ) : <Skeleton className="h-32" />}
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4 flex items-center gap-2">
            <TrendingUp className="w-3 h-3 text-primary" /> Top_Gainers
          </h3>
          <div className="space-y-2">
            {gainers?.slice(0, 5).map((c) => (
              <div key={c.symbol} data-testid={`text-gainer-${c.symbol}`} className="flex justify-between font-mono text-sm">
                <span className="text-foreground">{c.symbol.replace("USDT", "")}</span>
                <span className="text-primary font-bold">+{c.change24h.toFixed(2)}%</span>
              </div>
            )) ?? <Skeleton className="h-24" />}
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4 flex items-center gap-2">
            <TrendingDown className="w-3 h-3 text-destructive" /> Top_Losers
          </h3>
          <div className="space-y-2">
            {losers?.slice(0, 5).map((c) => (
              <div key={c.symbol} data-testid={`text-loser-${c.symbol}`} className="flex justify-between font-mono text-sm">
                <span className="text-foreground">{c.symbol.replace("USDT", "")}</span>
                <span className="text-destructive font-bold">{c.change24h.toFixed(2)}%</span>
              </div>
            )) ?? <Skeleton className="h-24" />}
          </div>
        </div>
      </div>
    </div>
  );
}
