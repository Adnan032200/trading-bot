import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { useLogin } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Activity } from "lucide-react";

const schema = z.object({
  emailOrUsername: z.string().min(1, "Required"),
  password: z.string().min(1, "Required"),
});

export default function LoginPage() {
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const loginMutation = useLogin();

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: { emailOrUsername: "", password: "" },
  });

  function onSubmit(values: z.infer<typeof schema>) {
    loginMutation.mutate(
      { data: values },
      {
        onSuccess: (data) => {
          login(data.token, data.user);
          setLocation("/dashboard");
        },
        onError: (err: any) => {
          toast({ title: "Login failed", description: err?.data?.error ?? "Invalid credentials", variant: "destructive" });
        },
      }
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

      <div className="w-full max-w-md px-8 py-10 relative">
        <div className="flex items-center justify-center gap-3 mb-10">
          <div className="w-10 h-10 rounded bg-primary flex items-center justify-center font-black text-background text-2xl shadow-[0_0_20px_rgba(0,255,136,0.5)]">
            X
          </div>
          <div>
            <h1 className="font-mono font-bold text-2xl tracking-wider text-primary">NEXUS_BOT</h1>
            <p className="text-xs font-mono text-muted-foreground">AI CRYPTO TRADING SYSTEM</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-8 shadow-xl">
          <div className="mb-6">
            <h2 className="font-mono text-lg font-bold tracking-wide">ACCESS_TERMINAL</h2>
            <p className="text-sm text-muted-foreground font-mono mt-1">Enter credentials to initialize session</p>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField control={form.control} name="emailOrUsername" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Email / Username</FormLabel>
                  <FormControl>
                    <Input data-testid="input-email" placeholder="trader@example.com" className="bg-background border-border font-mono" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="password" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Password</FormLabel>
                  <FormControl>
                    <Input data-testid="input-password" type="password" placeholder="••••••••" className="bg-background border-border font-mono" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <Button
                data-testid="button-login"
                type="submit"
                disabled={loginMutation.isPending}
                className="w-full font-mono tracking-widest bg-primary text-background hover:bg-primary/90 shadow-[0_0_15px_rgba(0,255,136,0.3)]"
              >
                {loginMutation.isPending ? "AUTHENTICATING..." : "INITIALIZE_SESSION"}
              </Button>
            </form>
          </Form>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground font-mono">
              No account?{" "}
              <Link href="/register" className="text-primary hover:underline">
                REGISTER_TERMINAL
              </Link>
            </p>
          </div>
        </div>

        <div className="mt-4 text-center text-xs font-mono text-muted-foreground/50">
          Demo: admin / admin123
        </div>
      </div>
    </div>
  );
}
