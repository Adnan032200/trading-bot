import { useState } from "react";
import { useGetTrades, useGetPerformance, getGetTradesQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function HistoryPage() {
  const [status, setStatus] = useState<"all" | "open" | "closed">("all");
  const [page, setPage] = useState(0);
  const limit = 20;

  const { data, isLoading } = useGetTrades(
    { status, limit, offset: page * limit },
    { query: { queryKey: getGetTradesQueryKey({ status, limit, offset: page * limit }) } }
  );
  const { data: performance } = useGetPerformance();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-bold tracking-wide">TRADE_HISTORY</h1>
        <p className="text-sm font-mono text-muted-foreground mt-1">Full log of all trading activity</p>
      </div>

      {/* Performance Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Trades", value: String(performance?.totalTrades ?? 0) },
          { label: "Win Rate", value: `${performance?.winRate ?? 0}%`, accent: true },
          { label: "Net Profit", value: `${(performance?.netProfit ?? 0) >= 0 ? '+' : ''}${(performance?.netProfit ?? 0).toFixed(4)} USDT`, accent: (performance?.netProfit ?? 0) >= 0, danger: (performance?.netProfit ?? 0) < 0 },
          { label: "Open Trades", value: String(performance?.openTrades ?? 0) },
        ].map(({ label, value, accent, danger }) => (
          <div key={label} className="bg-card border border-border rounded-lg p-4 font-mono">
            <p className="text-xs text-muted-foreground uppercase tracking-widest">{label}</p>
            <p className={`text-xl font-bold mt-1 ${accent ? 'text-primary' : danger ? 'text-destructive' : ''}`}>{value}</p>
          </div>
        ))}
      </div>

      {/* Best/Worst */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {performance?.bestTrade && (
          <div className="bg-card border border-primary/20 rounded-lg p-4 font-mono text-sm">
            <p className="text-xs text-primary uppercase tracking-widest mb-2">Best Trade</p>
            <p className="font-bold">{performance.bestTrade.symbol} <span className="text-primary">+{performance.bestTrade.profitLoss?.toFixed(4)} USDT</span></p>
            <p className="text-muted-foreground text-xs mt-1">{new Date(performance.bestTrade.openedAt).toLocaleDateString()}</p>
          </div>
        )}
        {performance?.worstTrade && (
          <div className="bg-card border border-destructive/20 rounded-lg p-4 font-mono text-sm">
            <p className="text-xs text-destructive uppercase tracking-widest mb-2">Worst Trade</p>
            <p className="font-bold">{performance.worstTrade.symbol} <span className="text-destructive">{performance.worstTrade.profitLoss?.toFixed(4)} USDT</span></p>
            <p className="text-muted-foreground text-xs mt-1">{new Date(performance.worstTrade.openedAt).toLocaleDateString()}</p>
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <Select value={status} onValueChange={(v) => { setStatus(v as any); setPage(0); }}>
          <SelectTrigger data-testid="select-status" className="w-40 font-mono bg-card border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Trades</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
        <span className="font-mono text-sm text-muted-foreground">{data?.total ?? 0} total</span>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="grid grid-cols-8 gap-2 px-4 py-3 border-b border-border text-xs font-mono text-muted-foreground uppercase tracking-widest">
          <span>Symbol</span>
          <span>Side</span>
          <span className="text-right">Amount</span>
          <span className="text-right">Entry</span>
          <span className="text-right">Exit</span>
          <span className="text-right">P&amp;L</span>
          <span>Status</span>
          <span>Time</span>
        </div>
        {isLoading ? (
          <div className="p-4 space-y-2">
            {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-10" />)}
          </div>
        ) : (
          <div className="divide-y divide-border/50">
            {data?.trades.map((trade) => (
              <div key={trade.id} data-testid={`row-trade-${trade.id}`} className="grid grid-cols-8 gap-2 px-4 py-3 font-mono text-sm hover:bg-muted/20 transition-colors">
                <span className="font-bold">{trade.symbol}</span>
                <span className={trade.side === "buy" ? "text-primary" : "text-destructive"}>{trade.side.toUpperCase()}</span>
                <span className="text-right text-muted-foreground">{trade.amount}</span>
                <span className="text-right">${trade.entryPrice.toFixed(2)}</span>
                <span className="text-right text-muted-foreground">{trade.exitPrice ? `$${trade.exitPrice.toFixed(2)}` : "---"}</span>
                <span className={`text-right font-bold ${trade.profitLoss != null ? (trade.profitLoss >= 0 ? 'text-primary' : 'text-destructive') : ''}`}>
                  {trade.profitLoss != null ? `${trade.profitLoss >= 0 ? '+' : ''}${trade.profitLoss.toFixed(4)}` : "---"}
                </span>
                <span>
                  <Badge variant={trade.status === "open" ? "default" : "secondary"} className={`font-mono text-xs ${trade.status === "open" ? "bg-primary/20 text-primary border-primary/30" : "bg-muted text-muted-foreground"}`}>
                    {trade.status.toUpperCase()}
                  </Badge>
                </span>
                <span className="text-muted-foreground text-xs">{new Date(trade.openedAt).toLocaleDateString()}</span>
              </div>
            ))}
            {data?.trades.length === 0 && (
              <div className="py-12 text-center font-mono text-muted-foreground">No trades found</div>
            )}
          </div>
        )}
      </div>

      {/* Pagination */}
      {data && data.total > limit && (
        <div className="flex items-center justify-center gap-3 font-mono text-sm">
          <button disabled={page === 0} onClick={() => setPage(p => p - 1)} className="px-4 py-2 bg-card border border-border rounded hover:bg-muted/50 disabled:opacity-40">PREV</button>
          <span className="text-muted-foreground">{page + 1} / {Math.ceil(data.total / limit)}</span>
          <button disabled={(page + 1) * limit >= data.total} onClick={() => setPage(p => p + 1)} className="px-4 py-2 bg-card border border-border rounded hover:bg-muted/50 disabled:opacity-40">NEXT</button>
        </div>
      )}
    </div>
  );
}
