import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetTradingStatus, useGetTradingSettings, useUpdateTradingSettings, useStartTrading, useStopTrading,
  useGetCandles, getGetTradingStatusQueryKey, getGetTradingSettingsQueryKey, getGetCandlesQueryKey
} from "@workspace/api-client-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { ComposedChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Zap, ZapOff } from "lucide-react";

const settingsSchema = z.object({
  profitTarget: z.coerce.number().min(0.1).max(100),
  stopLoss: z.coerce.number().min(0.1).max(100),
  tradeAmount: z.coerce.number().min(1),
  telegramChatId: z.string().optional(),
});

const INTERVALS = ["5m", "15m", "1h", "4h", "1d"] as const;
type Interval = typeof INTERVALS[number];

const CustomCandlestick = (props: any) => {
  const { x, y, width, height, payload } = props;
  if (!payload) return null;
  const { open, high, low, close } = payload;
  const isUp = close >= open;
  const color = isUp ? '#00ff88' : '#ff3366';
  const candleTop = Math.min(open, close);
  const candleHeight = Math.abs(close - open) || 0.5;

  return (
    <g>
      <line x1={x + width / 2} y1={y} x2={x + width / 2} y2={y + height} stroke={color} strokeWidth={1} opacity={0.6} />
    </g>
  );
};

export default function TradingPage() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [interval, setInterval] = useState<Interval>("1h");
  const [symbolInput, setSymbolInput] = useState("BTCUSDT");

  const { data: status } = useGetTradingStatus();
  const { data: settings } = useGetTradingSettings();
  const { data: candles, isLoading: candlesLoading } = useGetCandles(
    { symbol, interval, limit: 100 },
    { query: { queryKey: getGetCandlesQueryKey({ symbol, interval, limit: 100 }) } }
  );

  const updateMutation = useUpdateTradingSettings();
  const startMutation = useStartTrading();
  const stopMutation = useStopTrading();

  const form = useForm<z.infer<typeof settingsSchema>>({
    resolver: zodResolver(settingsSchema),
    values: settings ? {
      profitTarget: settings.profitTarget,
      stopLoss: settings.stopLoss,
      tradeAmount: settings.tradeAmount,
      telegramChatId: settings.telegramChatId ?? "",
    } : { profitTarget: 0.5, stopLoss: 0.6, tradeAmount: 10, telegramChatId: "" },
  });

  function onSaveSettings(values: z.infer<typeof settingsSchema>) {
    updateMutation.mutate({ data: values }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetTradingSettingsQueryKey() });
        toast({ title: "Settings saved", description: "Trading parameters updated" });
      },
    });
  }

  const handleToggle = () => {
    if (status?.isRunning) {
      stopMutation.mutate(undefined, {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getGetTradingStatusQueryKey() });
          toast({ title: "Bot stopped" });
        },
      });
    } else {
      startMutation.mutate(undefined, {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getGetTradingStatusQueryKey() });
          toast({ title: "Bot started", description: "Scanning for opportunities..." });
        },
      });
    }
  };

  const chartData = candles?.map(c => ({
    time: new Date(c.time * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    open: c.open, high: c.high, low: c.low, close: c.close,
    gain: c.close >= c.open ? c.close - c.open : 0,
    loss: c.close < c.open ? c.open - c.close : 0,
  })) ?? [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-mono font-bold tracking-wide">AUTO_TRADE</h1>
          <p className="text-sm font-mono text-muted-foreground mt-1">Trading agent controls and live charts</p>
        </div>
        <button
          data-testid="button-toggle-bot"
          onClick={handleToggle}
          disabled={startMutation.isPending || stopMutation.isPending}
          className={`flex items-center gap-2 px-6 py-3 rounded font-mono text-sm font-bold tracking-widest transition-all ${
            status?.isRunning
              ? 'bg-destructive/10 text-destructive border border-destructive/30 hover:bg-destructive/20'
              : 'bg-primary/10 text-primary border border-primary/30 hover:bg-primary/20 shadow-[0_0_15px_rgba(0,255,136,0.2)]'
          }`}
        >
          {status?.isRunning ? <ZapOff className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
          {status?.isRunning ? 'HALT_BOT' : 'LAUNCH_BOT'}
        </button>
      </div>

      {/* Status Panel */}
      <div className="bg-card border border-border rounded-lg p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className={`w-3 h-3 rounded-full ${status?.isRunning ? 'bg-primary animate-pulse shadow-[0_0_8px_rgba(0,255,136,0.8)]' : 'bg-muted-foreground'}`} />
          <span className="font-mono text-sm font-bold">{status?.isRunning ? 'AGENT_ACTIVE' : 'AGENT_OFFLINE'}</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-sm">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Symbol</p>
            <p className="font-bold text-primary">{status?.currentSymbol ?? '---'}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Position</p>
            <p className="font-bold">{status?.position ?? '---'}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">PNL</p>
            <p className={`font-bold ${status?.pnl != null ? (status.pnl >= 0 ? 'text-primary' : 'text-destructive') : ''}`}>
              {status?.pnl != null ? `${status.pnl >= 0 ? '+' : ''}${status.pnl.toFixed(4)} USDT` : '---'}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Started</p>
            <p className="font-bold text-muted-foreground">{status?.startedAt ? new Date(status.startedAt).toLocaleTimeString() : '---'}</p>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-card border border-border rounded-lg p-5">
        <div className="flex flex-wrap items-center gap-4 mb-4">
          <div className="flex items-center gap-2 flex-1">
            <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Symbol</span>
            <input
              value={symbolInput}
              onChange={e => setSymbolInput(e.target.value.toUpperCase())}
              onKeyDown={e => e.key === 'Enter' && setSymbol(symbolInput)}
              className="bg-background border border-border rounded px-3 py-1.5 font-mono text-sm w-36"
              placeholder="BTCUSDT"
            />
            <button onClick={() => setSymbol(symbolInput)} className="px-3 py-1.5 bg-primary/10 text-primary border border-primary/20 rounded font-mono text-xs hover:bg-primary/20">LOAD</button>
          </div>
          <div className="flex gap-1">
            {INTERVALS.map(iv => (
              <button
                key={iv}
                onClick={() => setInterval(iv)}
                className={`px-3 py-1.5 rounded font-mono text-xs ${interval === iv ? 'bg-primary text-background font-bold' : 'bg-muted text-muted-foreground hover:bg-muted/70'}`}
              >
                {iv}
              </button>
            ))}
          </div>
        </div>
        <div className="font-mono text-sm font-bold mb-3 text-primary">{symbol} — {interval}</div>
        {candlesLoading ? (
          <Skeleton className="h-64 w-full" />
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <ComposedChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="time" tick={{ fontSize: 10, fontFamily: 'monospace', fill: 'hsl(var(--muted-foreground))' }} interval="preserveStartEnd" />
              <YAxis tick={{ fontSize: 10, fontFamily: 'monospace', fill: 'hsl(var(--muted-foreground))' }} domain={['auto', 'auto']} width={70} />
              <Tooltip
                contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 6, fontFamily: 'monospace', fontSize: 12 }}
                formatter={(val: number, name: string) => [`$${val.toFixed(2)}`, name]}
              />
              <Bar dataKey="gain" fill="#00ff88" opacity={0.8} />
              <Bar dataKey="loss" fill="#ff3366" opacity={0.8} />
            </ComposedChart>
          </ResponsiveContainer>
        )}
        <p className="text-xs font-mono text-muted-foreground mt-2">Green bars = bullish candle, Red = bearish</p>
      </div>

      {/* Settings */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="font-mono text-sm font-bold uppercase tracking-widest mb-5">Trading_Parameters</h3>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSaveSettings)} className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <FormField control={form.control} name="profitTarget" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Profit Target (%)</FormLabel>
                <FormControl>
                  <Input data-testid="input-profit-target" type="number" step="0.01" className="bg-background border-border font-mono" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="stopLoss" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Stop Loss (%)</FormLabel>
                <FormControl>
                  <Input data-testid="input-stop-loss" type="number" step="0.01" className="bg-background border-border font-mono" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="tradeAmount" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Trade Amount (USDT)</FormLabel>
                <FormControl>
                  <Input data-testid="input-trade-amount" type="number" step="1" className="bg-background border-border font-mono" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="telegramChatId" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Telegram Chat ID (optional)</FormLabel>
                <FormControl>
                  <Input data-testid="input-telegram" placeholder="@yourusername" className="bg-background border-border font-mono" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="md:col-span-2">
              <Button
                data-testid="button-save-settings"
                type="submit"
                disabled={updateMutation.isPending}
                className="font-mono tracking-widest bg-primary text-background hover:bg-primary/90"
              >
                {updateMutation.isPending ? "SAVING..." : "SAVE_PARAMETERS"}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
