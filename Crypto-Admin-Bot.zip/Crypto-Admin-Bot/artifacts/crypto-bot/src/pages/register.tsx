import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { useRegister } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const schema = z.object({
  username: z.string().min(3, "Min 3 characters"),
  email: z.string().email("Invalid email"),
  password: z.string().min(8, "Min 8 characters"),
});

export default function RegisterPage() {
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const registerMutation = useRegister();

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: { username: "", email: "", password: "" },
  });

  function onSubmit(values: z.infer<typeof schema>) {
    registerMutation.mutate(
      { data: values },
      {
        onSuccess: (data) => {
          login(data.token, data.user);
          setLocation("/dashboard");
        },
        onError: (err: any) => {
          toast({ title: "Registration failed", description: err?.data?.error ?? "Could not create account", variant: "destructive" });
        },
      }
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none" />

      <div className="w-full max-w-md px-8 py-10 relative">
        <div className="flex items-center justify-center gap-3 mb-10">
          <div className="w-10 h-10 rounded bg-primary flex items-center justify-center font-black text-background text-2xl shadow-[0_0_20px_rgba(0,255,136,0.5)]">X</div>
          <div>
            <h1 className="font-mono font-bold text-2xl tracking-wider text-primary">NEXUS_BOT</h1>
            <p className="text-xs font-mono text-muted-foreground">AI CRYPTO TRADING SYSTEM</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-8 shadow-xl">
          <div className="mb-6">
            <h2 className="font-mono text-lg font-bold tracking-wide">CREATE_ACCOUNT</h2>
            <p className="text-sm text-muted-foreground font-mono mt-1">Register a new trading terminal</p>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField control={form.control} name="username" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Username</FormLabel>
                  <FormControl>
                    <Input data-testid="input-username" placeholder="trader_x" className="bg-background border-border font-mono" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="email" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Email</FormLabel>
                  <FormControl>
                    <Input data-testid="input-email" type="email" placeholder="trader@example.com" className="bg-background border-border font-mono" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="password" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Password</FormLabel>
                  <FormControl>
                    <Input data-testid="input-password" type="password" placeholder="Min 8 chars" className="bg-background border-border font-mono" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <Button
                data-testid="button-register"
                type="submit"
                disabled={registerMutation.isPending}
                className="w-full font-mono tracking-widest bg-primary text-background hover:bg-primary/90 shadow-[0_0_15px_rgba(0,255,136,0.3)]"
              >
                {registerMutation.isPending ? "CREATING..." : "REGISTER_TERMINAL"}
              </Button>
            </form>
          </Form>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground font-mono">
              Already registered?{" "}
              <Link href="/login" className="text-primary hover:underline">ACCESS_TERMINAL</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
