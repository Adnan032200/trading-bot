import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { useGetApiKey, useSaveApiKey, useDeleteApiKey, useTestApiKey, useUpdateProfile, getGetApiKeyQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, XCircle, AlertTriangle, Trash2 } from "lucide-react";

const apiKeySchema = z.object({
  apiKey: z.string().min(1, "Required"),
  apiSecret: z.string().min(1, "Required"),
});

const profileSchema = z.object({
  email: z.string().email().optional().or(z.literal("")),
  currentPassword: z.string().optional(),
  newPassword: z.string().min(8).optional().or(z.literal("")),
});

export default function SettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [showSecret, setShowSecret] = useState(false);

  const { data: apiKeyInfo, isLoading: apiKeyLoading } = useGetApiKey();
  const saveKeyMutation = useSaveApiKey();
  const deleteKeyMutation = useDeleteApiKey();
  const testKeyMutation = useTestApiKey();
  const updateProfileMutation = useUpdateProfile();

  const apiForm = useForm<z.infer<typeof apiKeySchema>>({
    resolver: zodResolver(apiKeySchema),
    defaultValues: { apiKey: "", apiSecret: "" },
  });

  const profileForm = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: { email: user?.email ?? "", currentPassword: "", newPassword: "" },
  });

  function onSaveApiKey(values: z.infer<typeof apiKeySchema>) {
    saveKeyMutation.mutate({ data: values }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetApiKeyQueryKey() });
        apiForm.reset();
        toast({ title: "API key saved", description: "Binance connection established" });
      },
      onError: () => toast({ title: "Failed to save API key", variant: "destructive" }),
    });
  }

  function onTestKey() {
    testKeyMutation.mutate(undefined, {
      onSuccess: (result) => {
        qc.invalidateQueries({ queryKey: getGetApiKeyQueryKey() });
        if (result.success) {
          toast({ title: "Connection successful", description: `Balance: ${result.balance?.toFixed(2)} USDT` });
        } else {
          toast({ title: "Connection failed", description: result.message, variant: "destructive" });
        }
      },
    });
  }

  function onDeleteKey() {
    deleteKeyMutation.mutate(undefined, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetApiKeyQueryKey() });
        toast({ title: "API key deleted" });
      },
    });
  }

  function onUpdateProfile(values: z.infer<typeof profileSchema>) {
    const payload: any = {};
    if (values.email) payload.email = values.email;
    if (values.newPassword) { payload.currentPassword = values.currentPassword; payload.newPassword = values.newPassword; }
    updateProfileMutation.mutate({ data: payload }, {
      onSuccess: () => toast({ title: "Profile updated" }),
      onError: (err: any) => toast({ title: "Update failed", description: err?.data?.error ?? "Error", variant: "destructive" }),
    });
  }

  return (
    <div className="space-y-8 max-w-2xl">
      <div>
        <h1 className="text-2xl font-mono font-bold tracking-wide">SETTINGS</h1>
        <p className="text-sm font-mono text-muted-foreground mt-1">API keys and account configuration</p>
      </div>

      {/* Binance API Key */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="font-mono text-sm font-bold uppercase tracking-widest mb-5">Binance_API_Connection</h3>

        {apiKeyLoading ? <Skeleton className="h-24" /> : (
          <>
            {apiKeyInfo?.hasKey && (
              <div className="mb-5 p-4 bg-background border border-border rounded-lg font-mono text-sm">
                <div className="flex items-center gap-2 mb-2">
                  {apiKeyInfo.status === "connected"
                    ? <CheckCircle className="w-4 h-4 text-primary" />
                    : <XCircle className="w-4 h-4 text-destructive" />}
                  <span className={apiKeyInfo.status === "connected" ? "text-primary font-bold" : "text-destructive font-bold"}>
                    {apiKeyInfo.status.toUpperCase()}
                  </span>
                </div>
                <p className="text-muted-foreground">Key: {apiKeyInfo.maskedKey}</p>
                {!apiKeyInfo.hasTradePermission && (
                  <div className="flex items-center gap-2 mt-2 text-yellow-400 text-xs">
                    <AlertTriangle className="w-3 h-3" />
                    No trading permissions — read-only access
                  </div>
                )}
                <div className="flex gap-2 mt-4">
                  <Button data-testid="button-test-key" onClick={onTestKey} disabled={testKeyMutation.isPending} size="sm" variant="outline" className="font-mono text-xs">
                    {testKeyMutation.isPending ? "TESTING..." : "TEST_CONNECTION"}
                  </Button>
                  <Button data-testid="button-delete-key" onClick={onDeleteKey} disabled={deleteKeyMutation.isPending} size="sm" variant="destructive" className="font-mono text-xs gap-1">
                    <Trash2 className="w-3 h-3" /> DELETE_KEY
                  </Button>
                </div>
              </div>
            )}

            <Form {...apiForm}>
              <form onSubmit={apiForm.handleSubmit(onSaveApiKey)} className="space-y-4">
                <FormField control={apiForm.control} name="apiKey" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">API Key</FormLabel>
                    <FormControl>
                      <Input data-testid="input-api-key" placeholder="Binance API Key" className="bg-background border-border font-mono" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={apiForm.control} name="apiSecret" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">API Secret</FormLabel>
                    <FormControl>
                      <Input data-testid="input-api-secret" type={showSecret ? "text" : "password"} placeholder="Binance API Secret" className="bg-background border-border font-mono" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <div className="flex gap-3">
                  <Button data-testid="button-save-api-key" type="submit" disabled={saveKeyMutation.isPending} className="font-mono tracking-widest bg-primary text-background hover:bg-primary/90">
                    {saveKeyMutation.isPending ? "SAVING..." : apiKeyInfo?.hasKey ? "UPDATE_KEY" : "SAVE_KEY"}
                  </Button>
                  <button type="button" onClick={() => setShowSecret(s => !s)} className="text-xs font-mono text-muted-foreground hover:text-foreground">
                    {showSecret ? "HIDE" : "SHOW"} SECRET
                  </button>
                </div>
              </form>
            </Form>
          </>
        )}
      </div>

      {/* Profile */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="font-mono text-sm font-bold uppercase tracking-widest mb-5">Profile_Settings</h3>
        <div className="mb-4 p-3 bg-background border border-border rounded font-mono text-sm">
          <span className="text-muted-foreground">Username: </span>
          <span className="font-bold">{user?.username}</span>
          <span className="mx-3 text-border">|</span>
          <span className="text-muted-foreground">Role: </span>
          <span className={`font-bold ${user?.role === 'admin' ? 'text-primary' : ''}`}>{user?.role?.toUpperCase()}</span>
        </div>
        <Form {...profileForm}>
          <form onSubmit={profileForm.handleSubmit(onUpdateProfile)} className="space-y-4">
            <FormField control={profileForm.control} name="email" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Email</FormLabel>
                <FormControl>
                  <Input data-testid="input-profile-email" type="email" className="bg-background border-border font-mono" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={profileForm.control} name="currentPassword" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Current Password</FormLabel>
                <FormControl>
                  <Input data-testid="input-current-password" type="password" placeholder="Required to change password" className="bg-background border-border font-mono" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={profileForm.control} name="newPassword" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">New Password</FormLabel>
                <FormControl>
                  <Input data-testid="input-new-password" type="password" placeholder="Min 8 characters" className="bg-background border-border font-mono" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <Button data-testid="button-save-profile" type="submit" disabled={updateProfileMutation.isPending} className="font-mono tracking-widest bg-primary text-background hover:bg-primary/90">
              {updateProfileMutation.isPending ? "SAVING..." : "UPDATE_PROFILE"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
