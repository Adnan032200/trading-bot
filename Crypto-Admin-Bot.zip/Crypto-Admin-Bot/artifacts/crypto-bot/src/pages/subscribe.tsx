import { useGetSubscriptionPlans, useGetCurrentSubscription } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle } from "lucide-react";

export default function SubscribePage() {
  const { data: plans, isLoading: plansLoading } = useGetSubscriptionPlans();
  const { data: current } = useGetCurrentSubscription();

  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <h1 className="text-2xl font-mono font-bold tracking-wide">SUBSCRIPTION</h1>
        <p className="text-sm font-mono text-muted-foreground mt-1">Choose your trading tier</p>
      </div>

      {current && (
        <div className={`bg-card border rounded-lg p-5 font-mono text-sm ${current.status === 'active' ? 'border-primary/30' : 'border-border'}`}>
          <p className="text-xs text-muted-foreground uppercase tracking-widest mb-2">Current Plan</p>
          <div className="flex items-center gap-3">
            <span className="text-xl font-bold">{current.planName}</span>
            <span className={`px-2 py-0.5 rounded text-xs font-bold ${current.status === 'active' ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'}`}>
              {current.status.toUpperCase()}
            </span>
          </div>
          {current.expiresAt && (
            <p className="text-muted-foreground text-xs mt-1">Expires: {new Date(current.expiresAt).toLocaleDateString()}</p>
          )}
        </div>
      )}

      {plansLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-64" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {plans?.map((plan, i) => {
            const isCurrentPlan = current?.planName === plan.name;
            const isPro = plan.name === "Pro";
            return (
              <div
                key={plan.id}
                data-testid={`card-plan-${plan.id}`}
                className={`bg-card border rounded-lg p-5 relative flex flex-col ${isPro ? 'border-primary/40 shadow-[0_0_20px_rgba(0,255,136,0.1)]' : 'border-border'}`}
              >
                {isPro && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-primary text-background text-xs font-mono font-bold rounded-full">
                    POPULAR
                  </div>
                )}
                <div className="font-mono mb-4">
                  <p className="text-xs text-muted-foreground uppercase tracking-widest">{plan.name}</p>
                  <p className="text-3xl font-bold mt-1">${plan.price}<span className="text-sm text-muted-foreground font-normal">/mo</span></p>
                  <p className="text-xs text-muted-foreground">{plan.durationDays} days</p>
                </div>
                <ul className="space-y-2 flex-1 font-mono text-xs">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <CheckCircle className="w-3 h-3 text-primary mt-0.5 shrink-0" />
                      <span className="text-muted-foreground">{f}</span>
                    </li>
                  ))}
                </ul>
                <button
                  data-testid={`button-select-plan-${plan.id}`}
                  className={`w-full mt-4 py-2 rounded font-mono text-sm font-bold tracking-widest transition-all ${
                    isCurrentPlan
                      ? 'bg-primary/10 text-primary border border-primary/30 cursor-default'
                      : isPro
                        ? 'bg-primary text-background hover:bg-primary/90'
                        : 'bg-muted text-foreground hover:bg-muted/70 border border-border'
                  }`}
                >
                  {isCurrentPlan ? 'CURRENT_PLAN' : plan.price === 0 ? 'GET_FREE' : 'SUBSCRIBE'}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
