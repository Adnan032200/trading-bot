import { useState } from "react";
import { useAdminGetAllTrades, getAdminGetAllTradesQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AdminTradesPage() {
  const [status, setStatus] = useState<"all" | "open" | "closed">("all");
  const [page, setPage] = useState(0);
  const limit = 20;

  const params = { status, limit, offset: page * limit };
  const { data, isLoading } = useAdminGetAllTrades(params, {
    query: { queryKey: getAdminGetAllTradesQueryKey(params) }
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-bold tracking-wide text-destructive">ALL_TRADES</h1>
        <p className="text-sm font-mono text-muted-foreground mt-1">Platform-wide trade history</p>
      </div>

      <div className="flex items-center gap-4">
        <Select value={status} onValueChange={(v) => { setStatus(v as any); setPage(0); }}>
          <SelectTrigger data-testid="select-status" className="w-40 font-mono bg-card border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Trades</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
        <span className="font-mono text-sm text-muted-foreground">{data?.total ?? 0} total</span>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="grid grid-cols-9 gap-2 px-4 py-3 border-b border-border text-xs font-mono text-muted-foreground uppercase tracking-widest">
          <span>User</span>
          <span>Symbol</span>
          <span>Side</span>
          <span className="text-right">Amount</span>
          <span className="text-right">Entry</span>
          <span className="text-right">Exit</span>
          <span className="text-right">P&amp;L</span>
          <span>Status</span>
          <span>Date</span>
        </div>
        {isLoading ? (
          <div className="p-4 space-y-2">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
        ) : (
          <div className="divide-y divide-border/50">
            {data?.trades.map((trade) => (
              <div key={trade.id} data-testid={`row-trade-${trade.id}`} className="grid grid-cols-9 gap-2 px-4 py-3 font-mono text-xs hover:bg-muted/20 transition-colors items-center">
                <span className="text-muted-foreground">{(trade as any).username ?? `#${trade.userId}`}</span>
                <span className="font-bold">{trade.symbol}</span>
                <span className={trade.side === "buy" ? "text-primary" : "text-destructive"}>{trade.side.toUpperCase()}</span>
                <span className="text-right text-muted-foreground">{trade.amount}</span>
                <span className="text-right">${trade.entryPrice.toFixed(2)}</span>
                <span className="text-right text-muted-foreground">{trade.exitPrice ? `$${trade.exitPrice.toFixed(2)}` : "---"}</span>
                <span className={`text-right font-bold ${trade.profitLoss != null ? (trade.profitLoss >= 0 ? 'text-primary' : 'text-destructive') : ''}`}>
                  {trade.profitLoss != null ? `${trade.profitLoss >= 0 ? '+' : ''}${trade.profitLoss.toFixed(4)}` : "---"}
                </span>
                <Badge variant="secondary" className={`font-mono text-xs w-fit ${trade.status === "open" ? "bg-primary/20 text-primary border-primary/30" : "bg-muted text-muted-foreground"}`}>
                  {trade.status.toUpperCase()}
                </Badge>
                <span className="text-muted-foreground">{new Date(trade.openedAt).toLocaleDateString()}</span>
              </div>
            ))}
            {data?.trades.length === 0 && (
              <div className="py-10 text-center font-mono text-muted-foreground">No trades found</div>
            )}
          </div>
        )}
      </div>

      {data && data.total > limit && (
        <div className="flex items-center justify-center gap-3 font-mono text-sm">
          <button disabled={page === 0} onClick={() => setPage(p => p - 1)} className="px-4 py-2 bg-card border border-border rounded hover:bg-muted/50 disabled:opacity-40">PREV</button>
          <span className="text-muted-foreground">{page + 1} / {Math.ceil(data.total / limit)}</span>
          <button disabled={(page + 1) * limit >= data.total} onClick={() => setPage(p => p + 1)} className="px-4 py-2 bg-card border border-border rounded hover:bg-muted/50 disabled:opacity-40">NEXT</button>
        </div>
      )}
    </div>
  );
}
