import { useAdminGetAnalytics, useAdminGetLogs } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, Activity, TrendingUp, Server, AlertCircle, ShieldCheck, Info } from "lucide-react";

const logIcon = (type: string) => {
  if (type === "auth") return <ShieldCheck className="w-3 h-3 text-secondary" />;
  if (type === "trade") return <TrendingUp className="w-3 h-3 text-primary" />;
  if (type === "error") return <AlertCircle className="w-3 h-3 text-destructive" />;
  return <Info className="w-3 h-3 text-muted-foreground" />;
};

export default function AdminPage() {
  const { data: analytics, isLoading: analyticsLoading } = useAdminGetAnalytics();
  const { data: logs, isLoading: logsLoading } = useAdminGetLogs({ limit: 20 });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-mono font-bold tracking-wide text-destructive">ADMIN_OVERVIEW</h1>
        <p className="text-sm font-mono text-muted-foreground mt-1">System control panel</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {analyticsLoading ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-lg" />) : (
          <>
            {[
              { label: "Total Users", value: String(analytics?.totalUsers ?? 0), icon: Users, color: "text-secondary" },
              { label: "Active Users", value: String(analytics?.activeUsers ?? 0), icon: Activity, color: "text-primary" },
              { label: "Total Trades", value: String(analytics?.totalTrades ?? 0), icon: TrendingUp, color: "text-primary" },
              { label: "Revenue", value: `$${(analytics?.totalRevenue ?? 0).toFixed(2)}`, icon: Server, color: "text-yellow-400" },
            ].map(({ label, value, icon: Icon, color }) => (
              <div key={label} className="bg-card border border-border rounded-lg p-5 relative overflow-hidden">
                <div className="absolute top-4 right-4 opacity-20"><Icon className={`w-8 h-8 ${color}`} /></div>
                <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-1">{label}</p>
                <p className={`text-2xl font-mono font-bold ${color}`}>{value}</p>
              </div>
            ))}
          </>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top Traders */}
        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">Top_Traders</h3>
          <div className="space-y-3">
            {analyticsLoading ? <Skeleton className="h-24" /> : analytics?.topTraders.map((trader, i) => (
              <div key={trader.userId} data-testid={`row-top-trader-${trader.userId}`} className="flex items-center gap-3 font-mono text-sm">
                <span className="text-muted-foreground w-6">{i + 1}</span>
                <span className="flex-1 font-bold">{trader.username}</span>
                <span className="text-muted-foreground">{trader.totalTrades} trades</span>
                <span className={`font-bold ${trader.netProfit >= 0 ? 'text-primary' : 'text-destructive'}`}>
                  {trader.netProfit >= 0 ? '+' : ''}{trader.netProfit.toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* System Health */}
        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">System_Health</h3>
          <div className="space-y-3 font-mono text-sm">
            {[
              { label: "API Server", status: "online" },
              { label: "Database", status: "online" },
              { label: "Binance Feed", status: "online" },
              { label: "Auth Service", status: "online" },
            ].map(({ label, status }) => (
              <div key={label} className="flex items-center justify-between">
                <span className="text-muted-foreground">{label}</span>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary shadow-[0_0_6px_rgba(0,255,136,0.8)] animate-pulse" />
                  <span className="text-primary text-xs">{status.toUpperCase()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Subscription Breakdown */}
      {analytics?.subscriptionBreakdown && analytics.subscriptionBreakdown.length > 0 && (
        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">Subscription_Breakdown</h3>
          <div className="flex flex-wrap gap-4">
            {analytics.subscriptionBreakdown.map((s) => (
              <div key={s.planName} className="bg-background border border-border rounded px-4 py-3 font-mono text-sm">
                <p className="text-muted-foreground text-xs uppercase tracking-widest">{s.planName}</p>
                <p className="text-xl font-bold text-primary">{s.count}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* System Logs */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-border">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest">System_Logs</h3>
        </div>
        {logsLoading ? (
          <div className="p-4 space-y-2">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-8" />)}</div>
        ) : (
          <div className="divide-y divide-border/50 max-h-96 overflow-y-auto">
            {(logs ?? []).map((log) => (
              <div key={log.id} data-testid={`row-log-${log.id}`} className="flex items-start gap-3 px-5 py-3 font-mono text-xs hover:bg-muted/20 transition-colors">
                <div className="mt-0.5">{logIcon(log.type)}</div>
                <div className="flex-1">
                  <span className="text-foreground">{log.message}</span>
                  {log.userId && <span className="text-muted-foreground ml-2">user:{log.userId}</span>}
                </div>
                <span className="text-muted-foreground shrink-0">{new Date(log.createdAt).toLocaleString()}</span>
              </div>
            ))}
            {(logs ?? []).length === 0 && (
              <div className="py-8 text-center font-mono text-muted-foreground text-sm">No logs</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
