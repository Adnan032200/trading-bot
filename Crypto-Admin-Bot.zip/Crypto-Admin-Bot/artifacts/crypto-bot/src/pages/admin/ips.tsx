import { useState } from "react";
import { useAdminGetBlockedIps, useAdminBlockIp, useAdminUnblockIp, getAdminGetBlockedIpsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Ban, Trash2, Plus } from "lucide-react";

export default function AdminIpsPage() {
  const [newIp, setNewIp] = useState("");
  const [newReason, setNewReason] = useState("");
  const qc = useQueryClient();
  const { toast } = useToast();

  const { data, isLoading } = useAdminGetBlockedIps();
  const blockMutation = useAdminBlockIp();
  const unblockMutation = useAdminUnblockIp();

  const refetch = () => qc.invalidateQueries({ queryKey: getAdminGetBlockedIpsQueryKey() });

  const handleBlock = () => {
    if (!newIp.trim()) return;
    blockMutation.mutate(
      { data: { ip: newIp.trim(), reason: newReason.trim() || undefined } },
      {
        onSuccess: () => {
          refetch();
          setNewIp("");
          setNewReason("");
          toast({ title: `IP ${newIp} blocked` });
        },
        onError: () => toast({ title: "Failed to block IP", variant: "destructive" }),
      }
    );
  };

  const handleUnblock = (id: number) => {
    unblockMutation.mutate({ id }, {
      onSuccess: () => { refetch(); toast({ title: "IP unblocked" }); },
    });
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-mono font-bold tracking-wide text-destructive">BLOCKED_IPS</h1>
        <p className="text-sm font-mono text-muted-foreground mt-1">Manage IP address blocklist</p>
      </div>

      <div className="bg-card border border-border rounded-lg p-5">
        <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">Block_New_IP</h3>
        <div className="flex gap-3 flex-wrap">
          <Input
            data-testid="input-new-ip"
            placeholder="IP Address (e.g. 192.168.1.1)"
            value={newIp}
            onChange={(e) => setNewIp(e.target.value)}
            className="bg-background border-border font-mono flex-1 min-w-40"
          />
          <Input
            data-testid="input-new-ip-reason"
            placeholder="Reason (optional)"
            value={newReason}
            onChange={(e) => setNewReason(e.target.value)}
            className="bg-background border-border font-mono flex-1 min-w-40"
          />
          <Button
            data-testid="button-block-ip"
            onClick={handleBlock}
            disabled={!newIp.trim() || blockMutation.isPending}
            className="font-mono tracking-widest bg-destructive text-white hover:bg-destructive/80 gap-1"
          >
            <Plus className="w-4 h-4" /> BLOCK_IP
          </Button>
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="grid grid-cols-5 gap-2 px-4 py-3 border-b border-border text-xs font-mono text-muted-foreground uppercase tracking-widest">
          <span className="col-span-2">IP Address</span>
          <span className="col-span-2">Reason</span>
          <span>Action</span>
        </div>
        {isLoading ? (
          <div className="p-4 space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
        ) : (
          <div className="divide-y divide-border/50">
            {(data ?? []).map((ip) => (
              <div key={ip.id} data-testid={`row-ip-${ip.id}`} className="grid grid-cols-5 gap-2 px-4 py-3 font-mono text-sm items-center hover:bg-muted/20 transition-colors">
                <div className="col-span-2 flex items-center gap-2">
                  <Ban className="w-3 h-3 text-destructive" />
                  <span className="font-bold text-destructive">{ip.ip}</span>
                </div>
                <span className="col-span-2 text-muted-foreground">{ip.reason ?? "—"}</span>
                <button
                  data-testid={`button-unblock-ip-${ip.id}`}
                  onClick={() => handleUnblock(ip.id)}
                  disabled={unblockMutation.isPending}
                  className="flex items-center gap-1 px-2 py-1 rounded text-xs font-mono border border-primary/30 text-primary hover:bg-primary/10 transition-colors w-fit"
                >
                  <Trash2 className="w-3 h-3" /> REMOVE
                </button>
              </div>
            ))}
            {(data ?? []).length === 0 && (
              <div className="py-10 text-center font-mono text-muted-foreground">No blocked IPs</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
