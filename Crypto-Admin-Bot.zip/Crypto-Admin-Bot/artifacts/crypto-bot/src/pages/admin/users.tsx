import { useState } from "react";
import { useAdminGetUsers, useAdminBlockUser, useAdminUpdateUserRole, getAdminGetUsersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Search, Ban, ShieldCheck, ShieldAlert } from "lucide-react";

export default function AdminUsersPage() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const limit = 20;
  const qc = useQueryClient();
  const { toast } = useToast();

  const params = { search: search || undefined, limit, offset: page * limit };
  const { data, isLoading } = useAdminGetUsers(params, {
    query: { queryKey: getAdminGetUsersQueryKey(params) }
  });

  const blockMutation = useAdminBlockUser();
  const roleMutation = useAdminUpdateUserRole();

  const refetch = () => qc.invalidateQueries({ queryKey: getAdminGetUsersQueryKey(params) });

  const handleBlock = (id: number, isBlocked: boolean) => {
    blockMutation.mutate(
      { id, data: { blocked: !isBlocked } },
      {
        onSuccess: () => { refetch(); toast({ title: isBlocked ? "User unblocked" : "User blocked" }); },
      }
    );
  };

  const handleRoleToggle = (id: number, role: string) => {
    const newRole = role === "admin" ? "user" : "admin";
    roleMutation.mutate(
      { id, data: { role: newRole as "user" | "admin" } },
      { onSuccess: () => { refetch(); toast({ title: `Role changed to ${newRole}` }); } }
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-bold tracking-wide text-destructive">USER_MANAGEMENT</h1>
        <p className="text-sm font-mono text-muted-foreground mt-1">Manage user accounts and permissions</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          data-testid="input-search-user"
          placeholder="Search by username or email..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
          className="pl-10 bg-background border-border font-mono"
        />
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="grid grid-cols-7 gap-2 px-4 py-3 border-b border-border text-xs font-mono text-muted-foreground uppercase tracking-widest">
          <span>ID</span>
          <span className="col-span-2">Username</span>
          <span className="col-span-2">Email</span>
          <span>Role</span>
          <span>Actions</span>
        </div>
        {isLoading ? (
          <div className="p-4 space-y-2">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
        ) : (
          <div className="divide-y divide-border/50">
            {data?.users.map((user) => (
              <div key={user.id} data-testid={`row-user-${user.id}`} className="grid grid-cols-7 gap-2 px-4 py-3 font-mono text-sm items-center hover:bg-muted/20 transition-colors">
                <span className="text-muted-foreground">#{user.id}</span>
                <div className="col-span-2">
                  <span className="font-bold">{user.username}</span>
                  {user.isBlocked && <Badge className="ml-2 bg-destructive/20 text-destructive border-destructive/30 text-xs">BLOCKED</Badge>}
                </div>
                <span className="col-span-2 text-muted-foreground truncate">{user.email}</span>
                <span>
                  <Badge className={`font-mono text-xs ${user.role === 'admin' ? 'bg-yellow-400/20 text-yellow-400 border-yellow-400/30' : 'bg-muted text-muted-foreground'}`}>
                    {user.role.toUpperCase()}
                  </Badge>
                </span>
                <div className="flex gap-1">
                  <button
                    data-testid={`button-block-${user.id}`}
                    onClick={() => handleBlock(user.id, user.isBlocked)}
                    disabled={blockMutation.isPending}
                    className={`p-1.5 rounded text-xs font-mono border transition-colors ${
                      user.isBlocked
                        ? 'border-primary/30 text-primary hover:bg-primary/10'
                        : 'border-destructive/30 text-destructive hover:bg-destructive/10'
                    }`}
                    title={user.isBlocked ? "Unblock" : "Block"}
                  >
                    {user.isBlocked ? <ShieldCheck className="w-3.5 h-3.5" /> : <Ban className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    data-testid={`button-role-${user.id}`}
                    onClick={() => handleRoleToggle(user.id, user.role)}
                    disabled={roleMutation.isPending}
                    className="p-1.5 rounded text-xs font-mono border border-yellow-400/30 text-yellow-400 hover:bg-yellow-400/10 transition-colors"
                    title="Toggle admin"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
            {data?.users.length === 0 && (
              <div className="py-10 text-center font-mono text-muted-foreground">No users found</div>
            )}
          </div>
        )}
      </div>

      {data && data.total > limit && (
        <div className="flex items-center justify-center gap-3 font-mono text-sm">
          <button disabled={page === 0} onClick={() => setPage(p => p - 1)} className="px-4 py-2 bg-card border border-border rounded hover:bg-muted/50 disabled:opacity-40">PREV</button>
          <span className="text-muted-foreground">{page + 1} / {Math.ceil(data.total / limit)}</span>
          <button disabled={(page + 1) * limit >= data.total} onClick={() => setPage(p => p + 1)} className="px-4 py-2 bg-card border border-border rounded hover:bg-muted/50 disabled:opacity-40">NEXT</button>
        </div>
      )}
    </div>
  );
}
