import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAdminGetSettings, useAdminUpdateSettings, useAdminGetLogs, getAdminGetSettingsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

const settingsSchema = z.object({
  defaultProfitTarget: z.coerce.number().min(0),
  defaultStopLoss: z.coerce.number().min(0),
  defaultTradeAmount: z.coerce.number().min(0),
  smtpHost: z.string().optional(),
  smtpPort: z.coerce.number().optional(),
  smtpUser: z.string().optional(),
});

export default function AdminSettingsPage() {
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: settings, isLoading } = useAdminGetSettings();
  const { data: logs } = useAdminGetLogs({ limit: 50 });
  const updateMutation = useAdminUpdateSettings();

  const form = useForm<z.infer<typeof settingsSchema>>({
    resolver: zodResolver(settingsSchema),
    values: settings ? {
      defaultProfitTarget: settings.defaultProfitTarget,
      defaultStopLoss: settings.defaultStopLoss,
      defaultTradeAmount: settings.defaultTradeAmount,
      smtpHost: settings.smtpHost ?? "",
      smtpPort: settings.smtpPort ?? undefined,
      smtpUser: settings.smtpUser ?? "",
    } : {
      defaultProfitTarget: 0.5, defaultStopLoss: 0.6, defaultTradeAmount: 10,
    },
  });

  function onSubmit(values: z.infer<typeof settingsSchema>) {
    updateMutation.mutate({
      data: {
        defaultProfitTarget: values.defaultProfitTarget,
        defaultStopLoss: values.defaultStopLoss,
        defaultTradeAmount: values.defaultTradeAmount,
        smtpHost: values.smtpHost || undefined,
        smtpPort: values.smtpPort || undefined,
        smtpUser: values.smtpUser || undefined,
      }
    }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getAdminGetSettingsQueryKey() });
        toast({ title: "Global settings saved" });
      },
      onError: () => toast({ title: "Failed to save settings", variant: "destructive" }),
    });
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-mono font-bold tracking-wide text-destructive">SYS_CONFIG</h1>
        <p className="text-sm font-mono text-muted-foreground mt-1">Global system configuration</p>
      </div>

      <div className="bg-card border border-border rounded-lg p-6 max-w-2xl">
        <h3 className="font-mono text-sm font-bold uppercase tracking-widest mb-5">Default_Trading_Parameters</h3>
        {isLoading ? <Skeleton className="h-64" /> : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <FormField control={form.control} name="defaultProfitTarget" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Default Profit Target (%)</FormLabel>
                    <FormControl><Input data-testid="input-profit-target" type="number" step="0.01" className="bg-background border-border font-mono" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="defaultStopLoss" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Default Stop Loss (%)</FormLabel>
                    <FormControl><Input data-testid="input-stop-loss" type="number" step="0.01" className="bg-background border-border font-mono" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="defaultTradeAmount" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Default Trade Amount (USDT)</FormLabel>
                    <FormControl><Input data-testid="input-trade-amount" type="number" step="1" className="bg-background border-border font-mono" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="pt-2">
                <h4 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">SMTP_Config (optional)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField control={form.control} name="smtpHost" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">SMTP Host</FormLabel>
                      <FormControl><Input data-testid="input-smtp-host" placeholder="smtp.example.com" className="bg-background border-border font-mono" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="smtpPort" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">SMTP Port</FormLabel>
                      <FormControl><Input data-testid="input-smtp-port" type="number" placeholder="587" className="bg-background border-border font-mono" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="smtpUser" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">SMTP User</FormLabel>
                      <FormControl><Input data-testid="input-smtp-user" placeholder="alerts@example.com" className="bg-background border-border font-mono" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              </div>

              <Button data-testid="button-save-settings" type="submit" disabled={updateMutation.isPending} className="font-mono tracking-widest bg-primary text-background hover:bg-primary/90">
                {updateMutation.isPending ? "SAVING..." : "SAVE_CONFIGURATION"}
              </Button>
            </form>
          </Form>
        )}
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-border">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Full_System_Logs</h3>
        </div>
        <div className="max-h-96 overflow-y-auto divide-y divide-border/50">
          {(logs ?? []).map((log) => (
            <div key={log.id} data-testid={`row-log-${log.id}`} className="flex items-start gap-3 px-5 py-2 font-mono text-xs hover:bg-muted/20">
              <span className={`shrink-0 px-1.5 py-0.5 rounded text-xs font-bold ${
                log.type === 'error' ? 'bg-destructive/20 text-destructive' :
                log.type === 'trade' ? 'bg-primary/20 text-primary' :
                log.type === 'auth' ? 'bg-secondary/20 text-secondary' :
                'bg-muted text-muted-foreground'
              }`}>{log.type.toUpperCase()}</span>
              <span className="flex-1">{log.message}</span>
              <span className="text-muted-foreground shrink-0">{new Date(log.createdAt).toLocaleString()}</span>
            </div>
          ))}
          {(logs ?? []).length === 0 && (
            <div className="py-8 text-center font-mono text-muted-foreground">No logs</div>
          )}
        </div>
      </div>
    </div>
  );
}
