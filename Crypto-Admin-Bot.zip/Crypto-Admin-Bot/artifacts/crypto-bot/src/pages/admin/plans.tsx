import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAdminGetPlans, useAdminCreatePlan, useAdminUpdatePlan, useAdminDeletePlan, getAdminGetPlansQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Pencil, Trash2, Plus, CheckCircle } from "lucide-react";

const planSchema = z.object({
  name: z.string().min(1, "Required"),
  price: z.coerce.number().min(0),
  durationDays: z.coerce.number().min(1),
  features: z.string().min(1, "Add comma-separated features"),
});

export default function AdminPlansPage() {
  const [editing, setEditing] = useState<number | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const qc = useQueryClient();
  const { toast } = useToast();

  const { data: plans, isLoading } = useAdminGetPlans();
  const createMutation = useAdminCreatePlan();
  const updateMutation = useAdminUpdatePlan();
  const deleteMutation = useAdminDeletePlan();

  const refetch = () => qc.invalidateQueries({ queryKey: getAdminGetPlansQueryKey() });

  const form = useForm<z.infer<typeof planSchema>>({
    resolver: zodResolver(planSchema),
    defaultValues: { name: "", price: 0, durationDays: 30, features: "" },
  });

  function onSubmit(values: z.infer<typeof planSchema>) {
    const payload = {
      name: values.name,
      price: values.price,
      durationDays: values.durationDays,
      features: values.features.split(",").map(f => f.trim()).filter(Boolean),
    };

    if (editing !== null) {
      updateMutation.mutate({ id: editing, data: payload }, {
        onSuccess: () => { refetch(); setEditing(null); setShowCreate(false); form.reset(); toast({ title: "Plan updated" }); },
      });
    } else {
      createMutation.mutate({ data: payload }, {
        onSuccess: () => { refetch(); setShowCreate(false); form.reset(); toast({ title: "Plan created" }); },
      });
    }
  }

  function startEdit(plan: any) {
    setEditing(plan.id);
    setShowCreate(true);
    form.setValue("name", plan.name);
    form.setValue("price", plan.price);
    form.setValue("durationDays", plan.durationDays);
    form.setValue("features", plan.features.join(", "));
  }

  function handleDelete(id: number) {
    deleteMutation.mutate({ id }, {
      onSuccess: () => { refetch(); toast({ title: "Plan deleted" }); },
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-mono font-bold tracking-wide text-destructive">PLAN_MANAGEMENT</h1>
          <p className="text-sm font-mono text-muted-foreground mt-1">Manage subscription plans</p>
        </div>
        <Button onClick={() => { setShowCreate(true); setEditing(null); form.reset(); }} className="font-mono tracking-widest bg-primary text-background hover:bg-primary/90 gap-1">
          <Plus className="w-4 h-4" /> NEW_PLAN
        </Button>
      </div>

      {(showCreate || editing !== null) && (
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="font-mono text-sm font-bold uppercase tracking-widest mb-5">{editing !== null ? "EDIT_PLAN" : "CREATE_PLAN"}</h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Plan Name</FormLabel>
                  <FormControl><Input data-testid="input-plan-name" className="bg-background border-border font-mono" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="price" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Price (USD/month)</FormLabel>
                  <FormControl><Input data-testid="input-plan-price" type="number" step="0.01" className="bg-background border-border font-mono" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="durationDays" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Duration (days)</FormLabel>
                  <FormControl><Input data-testid="input-plan-duration" type="number" className="bg-background border-border font-mono" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="features" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Features (comma-separated)</FormLabel>
                  <FormControl><Input data-testid="input-plan-features" placeholder="50 trades/day, Telegram alerts" className="bg-background border-border font-mono" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="md:col-span-2 flex gap-3">
                <Button data-testid="button-save-plan" type="submit" disabled={createMutation.isPending || updateMutation.isPending} className="font-mono tracking-widest bg-primary text-background hover:bg-primary/90">
                  {editing !== null ? "UPDATE_PLAN" : "CREATE_PLAN"}
                </Button>
                <Button type="button" variant="outline" onClick={() => { setShowCreate(false); setEditing(null); form.reset(); }} className="font-mono">CANCEL</Button>
              </div>
            </form>
          </Form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-64" />) : (
          (plans ?? []).map((plan) => (
            <div key={plan.id} data-testid={`card-plan-${plan.id}`} className="bg-card border border-border rounded-lg p-5 flex flex-col">
              <div className="flex items-start justify-between mb-3">
                <div className="font-mono">
                  <p className="text-xs text-muted-foreground uppercase tracking-widest">{plan.name}</p>
                  <p className="text-2xl font-bold mt-1">${plan.price}<span className="text-sm text-muted-foreground font-normal">/mo</span></p>
                  <p className="text-xs text-muted-foreground">{plan.durationDays}d</p>
                </div>
                <div className="flex gap-1">
                  <button data-testid={`button-edit-plan-${plan.id}`} onClick={() => startEdit(plan)} className="p-1.5 rounded border border-secondary/30 text-secondary hover:bg-secondary/10 transition-colors">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button data-testid={`button-delete-plan-${plan.id}`} onClick={() => handleDelete(plan.id)} className="p-1.5 rounded border border-destructive/30 text-destructive hover:bg-destructive/10 transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <ul className="space-y-1 flex-1 font-mono text-xs">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <CheckCircle className="w-3 h-3 text-primary mt-0.5 shrink-0" />
                    <span className="text-muted-foreground">{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
