import { useState } from "react";
import { useGetMarketCoins, useGetMarketSummary, useGetTopGainers, useGetTopLosers, getGetMarketCoinsQueryKey } from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown, Minus, Search } from "lucide-react";

function formatVolume(v: number): string {
  if (v >= 1e9) return `${(v / 1e9).toFixed(2)}B`;
  if (v >= 1e6) return `${(v / 1e6).toFixed(2)}M`;
  if (v >= 1e3) return `${(v / 1e3).toFixed(2)}K`;
  return v.toFixed(2);
}

export default function MarketPage() {
  const [search, setSearch] = useState("");

  const { data: coins, isLoading } = useGetMarketCoins(
    { search: search || undefined, limit: 200 },
    { query: { queryKey: getGetMarketCoinsQueryKey({ search: search || undefined, limit: 200 }) } }
  );
  const { data: summary } = useGetMarketSummary();
  const { data: gainers } = useGetTopGainers();
  const { data: losers } = useGetTopLosers();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-mono font-bold tracking-wide">MARKET_SCANNER</h1>
          <p className="text-sm font-mono text-muted-foreground mt-1">Live data from Binance — {summary?.totalCoins ?? 0} USDT pairs</p>
        </div>
      </div>

      {/* Market Summary Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-4 font-mono">
          <p className="text-xs text-muted-foreground uppercase tracking-widest">Total Coins</p>
          <p className="text-xl font-bold mt-1">{summary?.totalCoins ?? '---'}</p>
        </div>
        <div className="bg-card border border-primary/20 rounded-lg p-4 font-mono">
          <p className="text-xs text-primary uppercase tracking-widest">Rising</p>
          <p className="text-xl font-bold text-primary mt-1">{summary?.upCount ?? '---'}</p>
        </div>
        <div className="bg-card border border-destructive/20 rounded-lg p-4 font-mono">
          <p className="text-xs text-destructive uppercase tracking-widest">Falling</p>
          <p className="text-xl font-bold text-destructive mt-1">{summary?.downCount ?? '---'}</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 font-mono">
          <p className="text-xs text-muted-foreground uppercase tracking-widest">Stable</p>
          <p className="text-xl font-bold mt-1">{summary?.stableCount ?? '---'}</p>
        </div>
      </div>

      {/* Top Gainers/Losers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="font-mono text-xs text-primary uppercase tracking-widest mb-4 flex items-center gap-2">
            <TrendingUp className="w-3 h-3" /> Top_10_Gainers
          </h3>
          <div className="space-y-2">
            {gainers?.map((c, i) => (
              <div key={c.symbol} className="flex items-center justify-between font-mono text-sm py-1 border-b border-border/50 last:border-0">
                <span className="text-muted-foreground w-6">{i + 1}</span>
                <span className="flex-1 font-bold">{c.symbol.replace("USDT", "")}/USDT</span>
                <span className="text-foreground">${c.price.toFixed(c.price < 1 ? 6 : 2)}</span>
                <span className="text-primary font-bold ml-4 w-20 text-right">+{c.change24h.toFixed(2)}%</span>
              </div>
            )) ?? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-8" />)}
          </div>
        </div>
        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="font-mono text-xs text-destructive uppercase tracking-widest mb-4 flex items-center gap-2">
            <TrendingDown className="w-3 h-3" /> Top_10_Losers
          </h3>
          <div className="space-y-2">
            {losers?.map((c, i) => (
              <div key={c.symbol} className="flex items-center justify-between font-mono text-sm py-1 border-b border-border/50 last:border-0">
                <span className="text-muted-foreground w-6">{i + 1}</span>
                <span className="flex-1 font-bold">{c.symbol.replace("USDT", "")}/USDT</span>
                <span className="text-foreground">${c.price.toFixed(c.price < 1 ? 6 : 2)}</span>
                <span className="text-destructive font-bold ml-4 w-20 text-right">{c.change24h.toFixed(2)}%</span>
              </div>
            )) ?? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-8" />)}
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          data-testid="input-search-coin"
          placeholder="Search symbol (e.g. BTC, ETH, SOL)..."
          value={search}
          onChange={(e) => setSearch(e.target.value.toUpperCase())}
          className="pl-10 bg-background border-border font-mono"
        />
      </div>

      {/* Coins Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="grid grid-cols-6 gap-4 px-4 py-3 border-b border-border text-xs font-mono text-muted-foreground uppercase tracking-widest">
          <span>Symbol</span>
          <span className="text-right">Price</span>
          <span className="text-right">24h Change</span>
          <span className="text-right">24h High</span>
          <span className="text-right">24h Low</span>
          <span className="text-right">Volume</span>
        </div>
        {isLoading ? (
          <div className="p-4 space-y-2">
            {Array.from({ length: 10 }).map((_, i) => <Skeleton key={i} className="h-10" />)}
          </div>
        ) : (
          <div className="divide-y divide-border/50 max-h-[500px] overflow-y-auto">
            {coins?.map((coin) => (
              <div key={coin.symbol} data-testid={`row-coin-${coin.symbol}`} className="grid grid-cols-6 gap-4 px-4 py-3 font-mono text-sm hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-2">
                  {coin.direction === "up" ? <TrendingUp className="w-3 h-3 text-primary" /> :
                   coin.direction === "down" ? <TrendingDown className="w-3 h-3 text-destructive" /> :
                   <Minus className="w-3 h-3 text-muted-foreground" />}
                  <span className="font-bold">{coin.symbol.replace("USDT", "")}/USDT</span>
                </div>
                <span className="text-right">${coin.price.toFixed(coin.price < 1 ? 6 : 2)}</span>
                <span className={`text-right font-bold ${coin.change24h >= 0 ? 'text-primary' : 'text-destructive'}`}>
                  {coin.change24h >= 0 ? '+' : ''}{coin.change24h.toFixed(2)}%
                </span>
                <span className="text-right text-muted-foreground">${coin.high24h.toFixed(coin.high24h < 1 ? 6 : 2)}</span>
                <span className="text-right text-muted-foreground">${coin.low24h.toFixed(coin.low24h < 1 ? 6 : 2)}</span>
                <span className="text-right text-muted-foreground">{formatVolume(coin.volume24h)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
