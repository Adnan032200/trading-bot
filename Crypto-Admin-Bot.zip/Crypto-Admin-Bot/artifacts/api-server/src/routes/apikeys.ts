import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, apiKeysTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";
import { SaveApiKeyBody } from "@workspace/api-zod";
import { encrypt, decrypt, maskKey } from "../lib/encryption";

const router: IRouter = Router();

router.get("/apikeys", requireAuth, async (req, res): Promise<void> => {
  const [key] = await db
    .select()
    .from(apiKeysTable)
    .where(eq(apiKeysTable.userId, req.user!.userId))
    .limit(1);

  if (!key) {
    res.json({ hasKey: false, maskedKey: null, status: "disconnected", hasTradePermission: false, updatedAt: null });
    return;
  }

  res.json({
    hasKey: true,
    maskedKey: key.maskedKey,
    status: key.status,
    hasTradePermission: key.hasTradePermission,
    updatedAt: key.updatedAt.toISOString(),
  });
});

router.post("/apikeys", requireAuth, async (req, res): Promise<void> => {
  const parsed = SaveApiKeyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { apiKey, apiSecret } = parsed.data;
  const encryptedKey = encrypt(apiKey);
  const encryptedSecret = encrypt(apiSecret);
  const masked = maskKey(apiKey);

  const existing = await db
    .select()
    .from(apiKeysTable)
    .where(eq(apiKeysTable.userId, req.user!.userId))
    .limit(1);

  let result;
  if (existing.length > 0) {
    [result] = await db
      .update(apiKeysTable)
      .set({ encryptedKey, encryptedSecret, maskedKey: masked, status: "connected", hasTradePermission: false })
      .where(eq(apiKeysTable.userId, req.user!.userId))
      .returning();
  } else {
    [result] = await db
      .insert(apiKeysTable)
      .values({ userId: req.user!.userId, encryptedKey, encryptedSecret, maskedKey: masked })
      .returning();
  }

  res.json({
    hasKey: true,
    maskedKey: result.maskedKey,
    status: result.status,
    hasTradePermission: result.hasTradePermission,
    updatedAt: result.updatedAt.toISOString(),
  });
});

router.delete("/apikeys", requireAuth, async (req, res): Promise<void> => {
  await db.delete(apiKeysTable).where(eq(apiKeysTable.userId, req.user!.userId));
  res.json({ success: true, message: "API key deleted" });
});

router.post("/apikeys/test", requireAuth, async (req, res): Promise<void> => {
  const [key] = await db
    .select()
    .from(apiKeysTable)
    .where(eq(apiKeysTable.userId, req.user!.userId))
    .limit(1);

  if (!key) {
    res.json({ success: false, message: "No API key saved", hasTradePermission: false, balance: null });
    return;
  }

  try {
    const apiKey = decrypt(key.encryptedKey);
    const apiSecret = decrypt(key.encryptedSecret);
    const timestamp = Date.now();
    const queryString = `timestamp=${timestamp}`;

    const { createHmac } = await import("crypto");
    const signature = createHmac("sha256", apiSecret)
      .update(queryString)
      .digest("hex");

    const response = await fetch(
      `https://api.binance.com/api/v3/account?${queryString}&signature=${signature}`,
      { headers: { "X-MBX-APIKEY": apiKey } }
    );

    if (!response.ok) {
      await db.update(apiKeysTable)
        .set({ status: "disconnected" })
        .where(eq(apiKeysTable.userId, req.user!.userId));
      res.json({ success: false, message: "Invalid API key or connection failed", hasTradePermission: false, balance: null });
      return;
    }

    const data = await response.json() as { permissions?: string[]; balances?: { asset: string; free: string }[] };
    const hasTrade = data.permissions?.includes("SPOT") ?? false;
    const usdtBalance = data.balances?.find((b) => b.asset === "USDT")?.free ?? "0";

    await db.update(apiKeysTable)
      .set({ status: "connected", hasTradePermission: hasTrade })
      .where(eq(apiKeysTable.userId, req.user!.userId));

    res.json({
      success: true,
      message: hasTrade ? "Connected with trading permissions" : "Connected but no trading permissions",
      hasTradePermission: hasTrade,
      balance: parseFloat(usdtBalance),
    });
  } catch {
    res.json({ success: false, message: "Connection failed", hasTradePermission: false, balance: null });
  }
});

export default router;
