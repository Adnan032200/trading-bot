import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, tradingSettingsTable, systemLogsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";
import { UpdateTradingSettingsBody } from "@workspace/api-zod";

const router: IRouter = Router();

function formatSettings(s: typeof tradingSettingsTable.$inferSelect) {
  return {
    profitTarget: parseFloat(s.profitTarget),
    stopLoss: parseFloat(s.stopLoss),
    tradeAmount: parseFloat(s.tradeAmount),
    telegramChatId: s.telegramChatId ?? null,
  };
}

function formatStatus(s: typeof tradingSettingsTable.$inferSelect) {
  return {
    isRunning: s.isRunning,
    currentSymbol: s.currentSymbol ?? null,
    position: s.position ?? null,
    pnl: s.pnl ? parseFloat(s.pnl) : null,
    startedAt: s.startedAt?.toISOString() ?? null,
  };
}

async function getOrCreateSettings(userId: number) {
  const [settings] = await db
    .select()
    .from(tradingSettingsTable)
    .where(eq(tradingSettingsTable.userId, userId))
    .limit(1);

  if (settings) return settings;

  const [created] = await db.insert(tradingSettingsTable).values({ userId }).returning();
  return created;
}

router.get("/trading/status", requireAuth, async (req, res): Promise<void> => {
  const settings = await getOrCreateSettings(req.user!.userId);
  res.json(formatStatus(settings));
});

router.post("/trading/start", requireAuth, async (req, res): Promise<void> => {
  const [updated] = await db
    .update(tradingSettingsTable)
    .set({ isRunning: true, startedAt: new Date() })
    .where(eq(tradingSettingsTable.userId, req.user!.userId))
    .returning();

  await db.insert(systemLogsTable).values({
    type: "trade",
    message: "Trading agent started",
    userId: req.user!.userId,
  });

  res.json(formatStatus(updated));
});

router.post("/trading/stop", requireAuth, async (req, res): Promise<void> => {
  const [updated] = await db
    .update(tradingSettingsTable)
    .set({ isRunning: false, currentSymbol: null, position: null, pnl: null, startedAt: null })
    .where(eq(tradingSettingsTable.userId, req.user!.userId))
    .returning();

  await db.insert(systemLogsTable).values({
    type: "trade",
    message: "Trading agent stopped",
    userId: req.user!.userId,
  });

  res.json(formatStatus(updated));
});

router.get("/trading/settings", requireAuth, async (req, res): Promise<void> => {
  const settings = await getOrCreateSettings(req.user!.userId);
  res.json(formatSettings(settings));
});

router.patch("/trading/settings", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateTradingSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Partial<typeof tradingSettingsTable.$inferInsert> = {};
  if (parsed.data.profitTarget != null) updates.profitTarget = String(parsed.data.profitTarget);
  if (parsed.data.stopLoss != null) updates.stopLoss = String(parsed.data.stopLoss);
  if (parsed.data.tradeAmount != null) updates.tradeAmount = String(parsed.data.tradeAmount);
  if (parsed.data.telegramChatId != null) updates.telegramChatId = parsed.data.telegramChatId;

  const [updated] = await db
    .update(tradingSettingsTable)
    .set(updates)
    .where(eq(tradingSettingsTable.userId, req.user!.userId))
    .returning();

  res.json(formatSettings(updated));
});

export default router;
