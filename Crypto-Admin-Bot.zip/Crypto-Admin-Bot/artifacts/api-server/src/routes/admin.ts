import { Router, type IRouter } from "express";
import { eq, and, desc, count, sql, ilike, or } from "drizzle-orm";
import { db, usersTable, tradesTable, subscriptionPlansTable, userSubscriptionsTable, blockedIpsTable, systemLogsTable, globalSettingsTable, tradingSettingsTable } from "@workspace/db";
import { requireAdmin } from "../middlewares/auth";
import {
  AdminBlockUserBody,
  AdminBlockUserParams,
  AdminUpdateUserRoleBody,
  AdminUpdateUserRoleParams,
  AdminDeleteUserParams,
  AdminUpdateUserSubscriptionBody,
  AdminUpdateUserSubscriptionParams,
  AdminBlockIpBody,
  AdminUnblockIpParams,
  AdminCreatePlanBody,
  AdminUpdatePlanBody,
  AdminUpdatePlanParams,
  AdminDeletePlanParams,
  AdminGetAllTradesQueryParams,
  AdminGetUsersQueryParams,
  AdminGetLogsQueryParams,
  AdminUpdateSettingsBody,
  AdminUpdatePlanResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function formatAdminUser(user: typeof usersTable.$inferSelect) {
  const [sub] = await db.select().from(userSubscriptionsTable).where(eq(userSubscriptionsTable.userId, user.id)).limit(1);
  const [{ totalTrades }] = await db.select({ totalTrades: count() }).from(tradesTable).where(eq(tradesTable.userId, user.id));
  const trades = await db.select().from(tradesTable).where(and(eq(tradesTable.userId, user.id), eq(tradesTable.status, "closed")));
  const wins = trades.filter(t => t.profitLoss && parseFloat(t.profitLoss) > 0);
  const netProfit = trades.reduce((s, t) => s + (t.profitLoss ? parseFloat(t.profitLoss) : 0), 0);
  const winRate = trades.length > 0 ? (wins.length / trades.length) * 100 : 0;
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    isBlocked: user.isBlocked,
    createdAt: user.createdAt.toISOString(),
    lastLogin: user.lastLogin?.toISOString() ?? null,
    subscriptionStatus: sub?.status ?? "inactive",
    totalTrades: Number(totalTrades),
    netProfit: Math.round(netProfit * 100) / 100,
    winRate: Math.round(winRate * 10) / 10,
    ipAddress: user.ipAddress ?? null,
  };
}

function formatPlan(p: typeof subscriptionPlansTable.$inferSelect) {
  return { id: p.id, name: p.name, price: parseFloat(p.price), durationDays: p.durationDays, features: p.features, isActive: p.isActive };
}

function formatTrade(t: typeof tradesTable.$inferSelect) {
  return {
    id: t.id, userId: t.userId, symbol: t.symbol, side: t.side,
    amount: parseFloat(t.amount), entryPrice: parseFloat(t.entryPrice),
    exitPrice: t.exitPrice ? parseFloat(t.exitPrice) : null,
    profitLoss: t.profitLoss ? parseFloat(t.profitLoss) : null,
    status: t.status, duration: t.duration ?? null,
    openedAt: t.openedAt.toISOString(), closedAt: t.closedAt?.toISOString() ?? null,
  };
}

// USERS
router.get("/admin/users", requireAdmin, async (req, res): Promise<void> => {
  const params = AdminGetUsersQueryParams.safeParse(req.query);
  const limit = params.success ? (params.data.limit ?? 50) : 50;
  const offset = params.success ? (params.data.offset ?? 0) : 0;
  const search = params.success ? (params.data.search ?? "") : "";

  const conditions = search
    ? [or(ilike(usersTable.username, `%${search}%`), ilike(usersTable.email, `%${search}%`))]
    : [];

  const [userRows, [countRow]] = await Promise.all([
    db.select().from(usersTable).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(usersTable.createdAt)).limit(limit).offset(offset),
    db.select({ count: count() }).from(usersTable).where(conditions.length ? and(...conditions) : undefined),
  ]);

  const users = await Promise.all(userRows.map(formatAdminUser));
  res.json({ users, total: Number(countRow.count) });
});

router.patch("/admin/users/:id/block", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  const parsed = AdminBlockUserBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [user] = await db.update(usersTable).set({ isBlocked: parsed.data.blocked }).where(eq(usersTable.id, id)).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(await formatAdminUser(user));
});

router.patch("/admin/users/:id/role", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  const parsed = AdminUpdateUserRoleBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [user] = await db.update(usersTable).set({ role: parsed.data.role }).where(eq(usersTable.id, id)).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(await formatAdminUser(user));
});

router.delete("/admin/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  const [deleted] = await db.delete(usersTable).where(eq(usersTable.id, id)).returning();
  if (!deleted) { res.status(404).json({ error: "User not found" }); return; }
  res.json({ success: true, message: "User deleted" });
});

router.patch("/admin/users/:id/subscription", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const userId = parseInt(rawId, 10);
  const parsed = AdminUpdateUserSubscriptionBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const updates: Partial<typeof userSubscriptionsTable.$inferInsert> = { status: parsed.data.status };
  if (parsed.data.planId !== undefined) updates.planId = parsed.data.planId;
  if (parsed.data.expiresAt !== undefined) updates.expiresAt = parsed.data.expiresAt ? new Date(parsed.data.expiresAt) : null;
  if (parsed.data.status === "active") updates.startedAt = new Date();

  const existing = await db.select().from(userSubscriptionsTable).where(eq(userSubscriptionsTable.userId, userId)).limit(1);
  let sub;
  if (existing.length > 0) {
    [sub] = await db.update(userSubscriptionsTable).set(updates).where(eq(userSubscriptionsTable.userId, userId)).returning();
  } else {
    [sub] = await db.insert(userSubscriptionsTable).values({ userId, ...updates }).returning();
  }

  const [plan] = sub.planId ? await db.select().from(subscriptionPlansTable).where(eq(subscriptionPlansTable.id, sub.planId)).limit(1) : [null];
  res.json({
    id: sub.id, userId: sub.userId, planId: sub.planId ?? null,
    planName: plan?.name ?? "Free", status: sub.status,
    expiresAt: sub.expiresAt?.toISOString() ?? null, startedAt: sub.startedAt?.toISOString() ?? null,
  });
});

// IPS
router.get("/admin/ips", requireAdmin, async (_req, res): Promise<void> => {
  const ips = await db.select().from(blockedIpsTable).orderBy(desc(blockedIpsTable.blockedAt));
  res.json(ips.map(ip => ({ ...ip, blockedAt: ip.blockedAt.toISOString() })));
});

router.post("/admin/ips", requireAdmin, async (req, res): Promise<void> => {
  const parsed = AdminBlockIpBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [ip] = await db.insert(blockedIpsTable).values(parsed.data).returning();
  res.status(201).json({ ...ip, blockedAt: ip.blockedAt.toISOString() });
});

router.delete("/admin/ips/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  const [deleted] = await db.delete(blockedIpsTable).where(eq(blockedIpsTable.id, id)).returning();
  if (!deleted) { res.status(404).json({ error: "IP not found" }); return; }
  res.json({ success: true, message: "IP unblocked" });
});

// PLANS
router.get("/admin/plans", requireAdmin, async (_req, res): Promise<void> => {
  const plans = await db.select().from(subscriptionPlansTable);
  res.json(plans.map(formatPlan));
});

router.post("/admin/plans", requireAdmin, async (req, res): Promise<void> => {
  const parsed = AdminCreatePlanBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [plan] = await db.insert(subscriptionPlansTable).values({
    name: parsed.data.name,
    price: String(parsed.data.price),
    durationDays: parsed.data.durationDays,
    features: parsed.data.features,
    isActive: parsed.data.isActive ?? true,
  }).returning();
  res.status(201).json(formatPlan(plan));
});

router.patch("/admin/plans/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  const parsed = AdminUpdatePlanBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const updates: Partial<typeof subscriptionPlansTable.$inferInsert> = {};
  if (parsed.data.name) updates.name = parsed.data.name;
  if (parsed.data.price != null) updates.price = String(parsed.data.price);
  if (parsed.data.durationDays != null) updates.durationDays = parsed.data.durationDays;
  if (parsed.data.features) updates.features = parsed.data.features;
  if (parsed.data.isActive != null) updates.isActive = parsed.data.isActive;
  const [plan] = await db.update(subscriptionPlansTable).set(updates).where(eq(subscriptionPlansTable.id, id)).returning();
  if (!plan) { res.status(404).json({ error: "Plan not found" }); return; }
  res.json(formatPlan(plan));
});

router.delete("/admin/plans/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  const [deleted] = await db.delete(subscriptionPlansTable).where(eq(subscriptionPlansTable.id, id)).returning();
  if (!deleted) { res.status(404).json({ error: "Plan not found" }); return; }
  res.json({ success: true, message: "Plan deleted" });
});

// ALL TRADES
router.get("/admin/trades", requireAdmin, async (req, res): Promise<void> => {
  const params = AdminGetAllTradesQueryParams.safeParse(req.query);
  const limit = params.success ? (params.data.limit ?? 50) : 50;
  const offset = params.success ? (params.data.offset ?? 0) : 0;
  const status = params.success ? (params.data.status ?? "all") : "all";
  const userId = params.success ? params.data.userId : undefined;
  const symbol = params.success ? params.data.symbol : undefined;

  const conditions = [];
  if (status !== "all") conditions.push(eq(tradesTable.status, status));
  if (userId) conditions.push(eq(tradesTable.userId, userId));
  if (symbol) conditions.push(eq(tradesTable.symbol, symbol.toUpperCase()));

  const [tradeRows, [countRow]] = await Promise.all([
    db.select().from(tradesTable).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(tradesTable.openedAt)).limit(limit).offset(offset),
    db.select({ count: count() }).from(tradesTable).where(conditions.length ? and(...conditions) : undefined),
  ]);

  res.json({ trades: tradeRows.map(formatTrade), total: Number(countRow.count) });
});

// ANALYTICS
router.get("/admin/analytics", requireAdmin, async (_req, res): Promise<void> => {
  const [totalUsersRow] = await db.select({ count: count() }).from(usersTable);
  const allTrades = await db.select().from(tradesTable);
  const closedTrades = allTrades.filter(t => t.status === "closed");
  const totalVolume = allTrades.reduce((s, t) => s + parseFloat(t.amount) * parseFloat(t.entryPrice), 0);

  const subBreakdown = await db.select({ status: userSubscriptionsTable.status, count: count() })
    .from(userSubscriptionsTable).groupBy(userSubscriptionsTable.status);

  const topUsersMap = new Map<number, { netProfit: number; wins: number; total: number }>();
  for (const t of closedTrades) {
    const existing = topUsersMap.get(t.userId) ?? { netProfit: 0, wins: 0, total: 0 };
    const pnl = t.profitLoss ? parseFloat(t.profitLoss) : 0;
    topUsersMap.set(t.userId, { netProfit: existing.netProfit + pnl, wins: existing.wins + (pnl > 0 ? 1 : 0), total: existing.total + 1 });
  }

  const topUserIds = [...topUsersMap.entries()].sort((a, b) => b[1].netProfit - a[1].netProfit).slice(0, 5).map(([id]) => id);
  const topUserRows = topUserIds.length > 0
    ? await db.select().from(usersTable).where(sql`${usersTable.id} = ANY(${sql.raw(`ARRAY[${topUserIds.join(",")}]::int[]`)})`)
    : [];

  const topTraders = topUserRows.map(u => {
    const stats = topUsersMap.get(u.id)!;
    return { userId: u.id, username: u.username, totalTrades: stats.total, netProfit: Math.round(stats.netProfit * 100) / 100, winRate: Math.round((stats.wins / stats.total) * 1000) / 10 };
  });

  const recentTrades = allTrades.sort((a, b) => b.openedAt.getTime() - a.openedAt.getTime()).slice(0, 10);

  res.json({
    totalUsers: Number(totalUsersRow.count),
    activeUsers: Number(totalUsersRow.count),
    totalTrades: allTrades.length,
    totalVolume: Math.round(totalVolume * 100) / 100,
    totalRevenue: 0,
    pendingPayments: 0,
    topTraders,
    recentTrades: recentTrades.map(formatTrade),
    subscriptionBreakdown: subBreakdown.map(r => ({ planName: r.status, count: Number(r.count) })),
  });
});

// SETTINGS
router.get("/admin/settings", requireAdmin, async (_req, res): Promise<void> => {
  const [settings] = await db.select().from(globalSettingsTable).limit(1);
  if (!settings) {
    const [created] = await db.insert(globalSettingsTable).values({}).returning();
    res.json({
      defaultProfitTarget: parseFloat(created.defaultProfitTarget), defaultStopLoss: parseFloat(created.defaultStopLoss),
      defaultTradeAmount: parseFloat(created.defaultTradeAmount), smtpHost: null, smtpPort: null, smtpUser: null, smtpConfigured: false,
    });
    return;
  }
  res.json({
    defaultProfitTarget: parseFloat(settings.defaultProfitTarget), defaultStopLoss: parseFloat(settings.defaultStopLoss),
    defaultTradeAmount: parseFloat(settings.defaultTradeAmount), smtpHost: settings.smtpHost ?? null,
    smtpPort: settings.smtpPort ?? null, smtpUser: settings.smtpUser ?? null, smtpConfigured: settings.smtpConfigured,
  });
});

router.patch("/admin/settings", requireAdmin, async (req, res): Promise<void> => {
  const parsed = AdminUpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const updates: Partial<typeof globalSettingsTable.$inferInsert> = {};
  if (parsed.data.defaultProfitTarget != null) updates.defaultProfitTarget = String(parsed.data.defaultProfitTarget);
  if (parsed.data.defaultStopLoss != null) updates.defaultStopLoss = String(parsed.data.defaultStopLoss);
  if (parsed.data.defaultTradeAmount != null) updates.defaultTradeAmount = String(parsed.data.defaultTradeAmount);
  if (parsed.data.smtpHost) { updates.smtpHost = parsed.data.smtpHost; updates.smtpConfigured = true; }
  if (parsed.data.smtpPort != null) updates.smtpPort = parsed.data.smtpPort;
  if (parsed.data.smtpUser) updates.smtpUser = parsed.data.smtpUser;
  if (parsed.data.smtpPassword) updates.smtpPassword = parsed.data.smtpPassword;

  const existing = await db.select().from(globalSettingsTable).limit(1);
  let s;
  if (existing.length > 0) {
    [s] = await db.update(globalSettingsTable).set(updates).where(eq(globalSettingsTable.id, existing[0].id)).returning();
  } else {
    [s] = await db.insert(globalSettingsTable).values(updates).returning();
  }
  res.json({
    defaultProfitTarget: parseFloat(s.defaultProfitTarget), defaultStopLoss: parseFloat(s.defaultStopLoss),
    defaultTradeAmount: parseFloat(s.defaultTradeAmount), smtpHost: s.smtpHost ?? null,
    smtpPort: s.smtpPort ?? null, smtpUser: s.smtpUser ?? null, smtpConfigured: s.smtpConfigured,
  });
});

// NOTIFY
router.post("/admin/notify", requireAdmin, async (req, res): Promise<void> => {
  const { title, message } = req.body as { title?: string; message?: string };
  if (!title || !message) { res.status(400).json({ error: "Title and message required" }); return; }
  await db.insert(systemLogsTable).values({ type: "system", message: `Notification sent: ${title} - ${message}` });
  res.json({ success: true, message: `Notification sent to all users` });
});

// LOGS
router.get("/admin/logs", requireAdmin, async (req, res): Promise<void> => {
  const params = AdminGetLogsQueryParams.safeParse(req.query);
  const type = params.success ? (params.data.type ?? "all") : "all";
  const limit = params.success ? (params.data.limit ?? 100) : 100;

  const conditions = type !== "all" ? [eq(systemLogsTable.type, type)] : [];
  const logs = await db.select().from(systemLogsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(systemLogsTable.createdAt)).limit(limit);

  res.json(logs.map(l => ({ ...l, createdAt: l.createdAt.toISOString() })));
});

export default router;
