import { Router, type IRouter } from "express";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

interface BinanceTicker {
  symbol: string;
  lastPrice: string;
  priceChangePercent: string;
  highPrice: string;
  lowPrice: string;
  volume: string;
}

interface BinanceKline {
  0: number;
  1: string;
  2: string;
  3: string;
  4: string;
  5: string;
}

let cachedTickers: BinanceTicker[] = [];
let lastFetch = 0;
const CACHE_TTL = 10000;

async function fetchTickers(): Promise<BinanceTicker[]> {
  const now = Date.now();
  if (cachedTickers.length > 0 && now - lastFetch < CACHE_TTL) {
    return cachedTickers;
  }
  try {
    const response = await fetch("https://api.binance.com/api/v3/ticker/24hr");
    if (!response.ok) throw new Error("Binance API error");
    const data = await response.json() as BinanceTicker[];
    cachedTickers = data.filter((t) => t.symbol.endsWith("USDT"));
    lastFetch = now;
    return cachedTickers;
  } catch {
    return cachedTickers;
  }
}

function mapTicker(t: BinanceTicker) {
  const change = parseFloat(t.priceChangePercent);
  return {
    symbol: t.symbol,
    price: parseFloat(t.lastPrice),
    change24h: change,
    high24h: parseFloat(t.highPrice),
    low24h: parseFloat(t.lowPrice),
    volume24h: parseFloat(t.volume),
    direction: change > 0.1 ? "up" : change < -0.1 ? "down" : "stable",
  };
}

router.get("/market/coins", requireAuth, async (req, res): Promise<void> => {
  const tickers = await fetchTickers();
  const search = typeof req.query.search === "string" ? req.query.search.toUpperCase() : "";
  const limit = parseInt(req.query.limit as string, 10) || 100;

  let filtered = tickers;
  if (search) {
    filtered = tickers.filter((t) => t.symbol.includes(search));
  }

  const coins = filtered.slice(0, limit).map(mapTicker);
  res.json(coins);
});

router.get("/market/summary", requireAuth, async (req, res): Promise<void> => {
  const tickers = await fetchTickers();
  const coins = tickers.map(mapTicker);
  const upCount = coins.filter((c) => c.direction === "up").length;
  const downCount = coins.filter((c) => c.direction === "down").length;
  const stableCount = coins.filter((c) => c.direction === "stable").length;

  res.json({
    totalCoins: coins.length,
    upCount,
    downCount,
    stableCount,
    lastUpdated: new Date().toISOString(),
  });
});

router.get("/market/gainers", requireAuth, async (req, res): Promise<void> => {
  const tickers = await fetchTickers();
  const coins = tickers
    .map(mapTicker)
    .sort((a, b) => b.change24h - a.change24h)
    .slice(0, 10);
  res.json(coins);
});

router.get("/market/losers", requireAuth, async (req, res): Promise<void> => {
  const tickers = await fetchTickers();
  const coins = tickers
    .map(mapTicker)
    .sort((a, b) => a.change24h - b.change24h)
    .slice(0, 10);
  res.json(coins);
});

router.get("/market/candles", requireAuth, async (req, res): Promise<void> => {
  const symbol = typeof req.query.symbol === "string" ? req.query.symbol.toUpperCase() : "";
  const interval = typeof req.query.interval === "string" ? req.query.interval : "1h";
  const limit = parseInt(req.query.limit as string, 10) || 100;

  if (!symbol) {
    res.status(400).json({ error: "symbol is required" });
    return;
  }

  try {
    const response = await fetch(
      `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`
    );
    if (!response.ok) {
      res.status(400).json({ error: "Failed to fetch candles" });
      return;
    }
    const raw = await response.json() as BinanceKline[];
    const candles = raw.map((k) => ({
      time: Math.floor(k[0] / 1000),
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5]),
    }));
    res.json(candles);
  } catch {
    res.status(500).json({ error: "Failed to fetch candles" });
  }
});

export default router;
