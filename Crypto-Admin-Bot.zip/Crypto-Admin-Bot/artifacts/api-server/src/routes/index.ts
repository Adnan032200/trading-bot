import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import apikeysRouter from "./apikeys";
import marketRouter from "./market";
import tradingRouter from "./trading";
import tradesRouter from "./trades";
import subscriptionsRouter from "./subscriptions";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(apikeysRouter);
router.use(marketRouter);
router.use(tradingRouter);
router.use(tradesRouter);
router.use(subscriptionsRouter);
router.use(adminRouter);

export default router;
