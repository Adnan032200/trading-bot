import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, subscriptionPlansTable, userSubscriptionsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

function formatPlan(p: typeof subscriptionPlansTable.$inferSelect) {
  return {
    id: p.id,
    name: p.name,
    price: parseFloat(p.price),
    durationDays: p.durationDays,
    features: p.features,
    isActive: p.isActive,
  };
}

router.get("/subscriptions/plans", requireAuth, async (_req, res): Promise<void> => {
  const plans = await db
    .select()
    .from(subscriptionPlansTable)
    .where(eq(subscriptionPlansTable.isActive, true));
  res.json(plans.map(formatPlan));
});

router.get("/subscriptions/current", requireAuth, async (req, res): Promise<void> => {
  const [sub] = await db
    .select({
      sub: userSubscriptionsTable,
      plan: subscriptionPlansTable,
    })
    .from(userSubscriptionsTable)
    .leftJoin(subscriptionPlansTable, eq(userSubscriptionsTable.planId, subscriptionPlansTable.id))
    .where(eq(userSubscriptionsTable.userId, req.user!.userId))
    .limit(1);

  if (!sub) {
    res.json({
      id: 0,
      userId: req.user!.userId,
      planId: null,
      planName: "Free",
      status: "inactive",
      expiresAt: null,
      startedAt: null,
    });
    return;
  }

  res.json({
    id: sub.sub.id,
    userId: sub.sub.userId,
    planId: sub.sub.planId ?? null,
    planName: sub.plan?.name ?? "Free",
    status: sub.sub.status,
    expiresAt: sub.sub.expiresAt?.toISOString() ?? null,
    startedAt: sub.sub.startedAt?.toISOString() ?? null,
  });
});

export default router;
