import { Router, type IRouter } from "express";
import { eq, and, desc, count, sql } from "drizzle-orm";
import { db, tradesTable, apiKeysTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";
import { decrypt } from "../lib/encryption";

const router: IRouter = Router();

function formatTrade(t: typeof tradesTable.$inferSelect) {
  return {
    id: t.id,
    userId: t.userId,
    symbol: t.symbol,
    side: t.side,
    amount: parseFloat(t.amount),
    entryPrice: parseFloat(t.entryPrice),
    exitPrice: t.exitPrice ? parseFloat(t.exitPrice) : null,
    profitLoss: t.profitLoss ? parseFloat(t.profitLoss) : null,
    status: t.status,
    duration: t.duration ?? null,
    openedAt: t.openedAt.toISOString(),
    closedAt: t.closedAt?.toISOString() ?? null,
  };
}

router.get("/trades", requireAuth, async (req, res): Promise<void> => {
  const status = typeof req.query.status === "string" ? req.query.status : "all";
  const symbol = typeof req.query.symbol === "string" ? req.query.symbol : "";
  const limit = parseInt(req.query.limit as string, 10) || 50;
  const offset = parseInt(req.query.offset as string, 10) || 0;

  const conditions = [eq(tradesTable.userId, req.user!.userId)];
  if (status !== "all") conditions.push(eq(tradesTable.status, status));
  if (symbol) conditions.push(eq(tradesTable.symbol, symbol.toUpperCase()));

  const [tradeRows, [countRow]] = await Promise.all([
    db
      .select()
      .from(tradesTable)
      .where(and(...conditions))
      .orderBy(desc(tradesTable.openedAt))
      .limit(limit)
      .offset(offset),
    db
      .select({ count: count() })
      .from(tradesTable)
      .where(and(...conditions)),
  ]);

  res.json({ trades: tradeRows.map(formatTrade), total: Number(countRow.count) });
});

router.get("/trades/performance", requireAuth, async (req, res): Promise<void> => {
  const userId = req.user!.userId;
  const allTrades = await db
    .select()
    .from(tradesTable)
    .where(eq(tradesTable.userId, userId))
    .orderBy(desc(tradesTable.openedAt));

  const closed = allTrades.filter((t) => t.status === "closed");
  const open = allTrades.filter((t) => t.status === "open");
  const wins = closed.filter((t) => t.profitLoss && parseFloat(t.profitLoss) > 0);
  const netProfit = closed.reduce((sum, t) => sum + (t.profitLoss ? parseFloat(t.profitLoss) : 0), 0);
  const winRate = closed.length > 0 ? (wins.length / closed.length) * 100 : 0;

  const sortedByPnl = [...closed].sort((a, b) => {
    const ap = a.profitLoss ? parseFloat(a.profitLoss) : 0;
    const bp = b.profitLoss ? parseFloat(b.profitLoss) : 0;
    return bp - ap;
  });

  res.json({
    totalTrades: allTrades.length,
    openTrades: open.length,
    winRate: Math.round(winRate * 10) / 10,
    netProfit: Math.round(netProfit * 100) / 100,
    bestTrade: sortedByPnl[0] ? formatTrade(sortedByPnl[0]) : null,
    worstTrade: sortedByPnl[sortedByPnl.length - 1] ? formatTrade(sortedByPnl[sortedByPnl.length - 1]) : null,
  });
});

router.get("/trades/balance", requireAuth, async (req, res): Promise<void> => {
  const [key] = await db
    .select()
    .from(apiKeysTable)
    .where(eq(apiKeysTable.userId, req.user!.userId))
    .limit(1);

  if (!key) {
    res.json({ usdtBalance: 0, lastFetched: new Date().toISOString() });
    return;
  }

  try {
    const apiKey = decrypt(key.encryptedKey);
    const apiSecret = decrypt(key.encryptedSecret);
    const timestamp = Date.now();
    const queryString = `timestamp=${timestamp}`;
    const { createHmac } = await import("crypto");
    const signature = createHmac("sha256", apiSecret).update(queryString).digest("hex");

    const response = await fetch(
      `https://api.binance.com/api/v3/account?${queryString}&signature=${signature}`,
      { headers: { "X-MBX-APIKEY": apiKey } }
    );

    if (!response.ok) {
      res.json({ usdtBalance: 0, lastFetched: new Date().toISOString() });
      return;
    }

    const data = await response.json() as { balances?: { asset: string; free: string }[] };
    const usdt = data.balances?.find((b) => b.asset === "USDT")?.free ?? "0";
    res.json({ usdtBalance: parseFloat(usdt), lastFetched: new Date().toISOString() });
  } catch {
    res.json({ usdtBalance: 0, lastFetched: new Date().toISOString() });
  }
});

export default router;
