import { pgTable, serial, integer, text, numeric, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const tradingSettingsTable = pgTable("trading_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }).unique(),
  profitTarget: numeric("profit_target", { precision: 6, scale: 2 }).notNull().default("0.5"),
  stopLoss: numeric("stop_loss", { precision: 6, scale: 2 }).notNull().default("0.6"),
  tradeAmount: numeric("trade_amount", { precision: 18, scale: 2 }).notNull().default("10"),
  telegramChatId: text("telegram_chat_id"),
  isRunning: boolean("is_running").notNull().default(false),
  currentSymbol: text("current_symbol"),
  position: text("position"),
  pnl: numeric("pnl", { precision: 18, scale: 8 }),
  startedAt: timestamp("started_at", { withTimezone: true }),
});

export const insertTradingSettingsSchema = createInsertSchema(tradingSettingsTable).omit({ id: true });
export type InsertTradingSettings = z.infer<typeof insertTradingSettingsSchema>;
export type TradingSettings = typeof tradingSettingsTable.$inferSelect;
