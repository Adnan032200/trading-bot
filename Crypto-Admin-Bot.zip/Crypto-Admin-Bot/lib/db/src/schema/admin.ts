import { pgTable, serial, integer, text, numeric, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const blockedIpsTable = pgTable("blocked_ips", {
  id: serial("id").primaryKey(),
  ip: text("ip").notNull().unique(),
  reason: text("reason").notNull(),
  blockedAt: timestamp("blocked_at", { withTimezone: true }).notNull().defaultNow(),
});

export const systemLogsTable = pgTable("system_logs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull().default("system"),
  message: text("message").notNull(),
  userId: integer("user_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const globalSettingsTable = pgTable("global_settings", {
  id: serial("id").primaryKey(),
  defaultProfitTarget: numeric("default_profit_target", { precision: 6, scale: 2 }).notNull().default("0.5"),
  defaultStopLoss: numeric("default_stop_loss", { precision: 6, scale: 2 }).notNull().default("0.6"),
  defaultTradeAmount: numeric("default_trade_amount", { precision: 18, scale: 2 }).notNull().default("10"),
  smtpHost: text("smtp_host"),
  smtpPort: integer("smtp_port"),
  smtpUser: text("smtp_user"),
  smtpPassword: text("smtp_password"),
  smtpConfigured: boolean("smtp_configured").notNull().default(false),
});

export const insertBlockedIpSchema = createInsertSchema(blockedIpsTable).omit({ id: true, blockedAt: true });
export type InsertBlockedIp = z.infer<typeof insertBlockedIpSchema>;
export type BlockedIp = typeof blockedIpsTable.$inferSelect;

export const insertSystemLogSchema = createInsertSchema(systemLogsTable).omit({ id: true, createdAt: true });
export type InsertSystemLog = z.infer<typeof insertSystemLogSchema>;
export type SystemLog = typeof systemLogsTable.$inferSelect;
