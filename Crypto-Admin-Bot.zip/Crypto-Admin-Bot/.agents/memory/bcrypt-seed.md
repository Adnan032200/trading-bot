---
name: Bcrypt seed fix
description: How to generate correct bcrypt hashes for database seeding in this project
---

## Problem

When seeding users with hardcoded bcrypt hashes (placeholder values), logins fail because the hash doesn't match the password.

## Solution

Generate real hashes using the api-server's local bcrypt module:

```bash
node -e "
const bcrypt = require('/home/runner/workspace/artifacts/api-server/node_modules/bcrypt');
bcrypt.hash('yourpassword', 10).then(h => console.log(h));
"
```

Then update the DB:
```sql
UPDATE users SET password_hash = '<generated_hash>' WHERE username = 'admin';
```

**Why:** The workspace root and code_execution sandbox don't have bcrypt installed. The api-server package has it at its own node_modules. Using `require()` with an absolute path works.

**How to apply:** Any time you add seed users (via SQL or code_execution), always generate hashes this way rather than using placeholder strings.
