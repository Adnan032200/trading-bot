# NEXUS_BOT — AI Crypto Trading Bot

A full-stack AI crypto trading platform with real-time Binance market data, automated trading agent, and a complete admin panel.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, proxied at `/api`)
- `pnpm --filter @workspace/crypto-bot run dev` — run the React frontend (proxied at `/`)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL`, `SESSION_SECRET`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui (dark cockpit theme)
- API: Express 5 at `/api`
- DB: PostgreSQL + Drizzle ORM
- Auth: JWT (HS256) via SESSION_SECRET, bcrypt passwords
- API keys: AES-256-CBC encrypted in DB
- Validation: Zod (`zod/v4`), `drizzle-zod`, Orval codegen
- Market data: Public Binance REST API (10s in-memory cache)
- Charts: Recharts (candlestick via ComposedChart)

## Where things live

- `artifacts/crypto-bot/src/pages/` — user-facing pages (dashboard, market, trading, history, settings, subscribe)
- `artifacts/crypto-bot/src/pages/admin/` — admin pages (overview, users, blocked IPs, plans, all trades, sys config)
- `artifacts/crypto-bot/src/contexts/AuthContext.tsx` — JWT auth context, token in localStorage
- `artifacts/api-server/src/routes/` — all API routes (auth, apikeys, market, trading, trades, subscriptions, admin)
- `artifacts/api-server/src/middlewares/auth.ts` — JWT sign/verify, `requireAuth`, `requireAdmin`
- `artifacts/api-server/src/lib/encryption.ts` — AES-256-CBC for Binance API key storage
- `lib/db/src/schema/` — all Drizzle schemas (users, apiKeys, trades, subscriptions, tradingSettings, admin tables)
- `lib/api-client-react/src/generated/api.ts` — Orval-generated hooks (do not edit manually)

## Architecture decisions

- Market data endpoints require auth to prevent public scraping abuse
- Binance API keys encrypted with AES-256-CBC before storing in PostgreSQL
- JWT tokens stored in localStorage + injected via `setAuthTokenGetter` into all API client fetches
- Admin hooks generated with `Admin` prefix (e.g., `useAdminGetUsers`, `useAdminGetAnalytics`)
- OpenAPI spec at `lib/api-spec/` is source-of-truth — always run codegen after changing it
- DB schema uses `snake_case` column names with camelCase TypeScript mapping via Drizzle

## Product

**User features:**
- Login/Register with JWT auth
- Dashboard: live bot status, P&L, market movers (top gainers/losers)
- Market Scanner: 430+ USDT pairs with real-time Binance data
- Auto Trade: candlestick charts (Recharts), bot controls, configurable parameters
- Trade History: full log with win rate, net profit, pagination
- Settings: encrypted Binance API key storage + connection test
- Subscription: tiered plans (Free/Basic/Pro/Enterprise)

**Admin features (admin role only):**
- Overview: platform stats, top traders, system health, logs
- User Management: block/unblock, toggle admin role, search
- Blocked IPs: add/remove IP blocklist
- Plan Management: CRUD subscription plans
- All Trades: cross-user trade history with filters
- System Config: default trading parameters + SMTP settings

## Seed accounts

| Username | Email | Password | Role |
|----------|-------|----------|------|
| admin | admin@cryptobot.com | admin123 | admin |
| alice | alice@example.com | admin123 | user |
| bob | bob@example.com | admin123 | user |

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Always run `pnpm --filter @workspace/api-spec run codegen` after changing the OpenAPI spec
- Admin hooks use `useAdmin*` prefix, not `useGet*` — check generated api.ts before writing pages
- `adminGetLogs` returns `SystemLog[]` directly (not `{logs: [], total: number}`)
- `GlobalSettings` schema has `defaultProfitTarget`, `defaultStopLoss`, `defaultTradeAmount` — NOT `tradingEnabled`/`maintenanceMode`
- `useAdminBlockUser` takes `{id, data: {blocked: boolean}}` (not separate block/unblock hooks)
- Market data is cached for 10s in memory; restarting API server clears cache

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
